import java.io.Serializable;
import java.util.Date;

/**
 * Created by lchero on 2018/8/23.
 */
public class Comments implements Serializable {
    private String id;  //评论id 用于和话题绑定。
    private String comName;   //评论者的名字
    private String comment;   //评论者的话
    public Date time;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Comments(String id, String comName, String comment, Date time) {
        this.id = id;
        this.comName = comName;
        this.comment = comment;
        this.time = time;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comName) {
        this.comName = comName;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
