import jdk.management.resource.internal.inst.FileOutputStreamRMHooks;

import java.io.*;
import java.net.Socket;
import java.util.*;

/**
 * Created by lchero on 2018/8/21.
 */
// 方法类
public class Funtion {
    Scanner input=new Scanner(System.in);
    //调用集合存储评论信息
    ArrayList<Comments> listcom=Setclass.listcom;
    public void shuchuCom(){
        ObjectOutputStream oos=null;
        try {
            oos=new ObjectOutputStream(new FileOutputStream("D:\\Java课后作业\\小组项目\\servers\\Com.txt"));
            oos.writeObject(listcom);
            //f=false;
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public void shuruCom(){
        ObjectInputStream ois=null;
        FileInputStream fis= null;

        try {
            fis = new FileInputStream("D:\\Java课后作业\\小组项目\\servers\\Com.txt");
            //当文件中的有内容时
            if(fis.available()!=0){
                ois=new ObjectInputStream(fis);
                ArrayList<Comments> mapTop=(ArrayList<Comments>) ois.readObject();
                this.listcom=mapTop;
                return;
            }else {
                System.out.println("文件为空,请先注册!");
                //this.f=true;
                return;

            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }finally {
            try {
                //if (!f){
                ois.close();
                // }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
    //调用集合存储用户信息
    ArrayList<User> listUser=Setclass.listUser;
    public void shuchuUser(){
        ObjectOutputStream oos=null;
        try {
            oos=new ObjectOutputStream(new FileOutputStream("D:\\Java课后作业\\小组项目\\servers\\User.txt"));
            oos.writeObject(listUser);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public void shuruUser(){
        ObjectInputStream ois=null;
        FileInputStream fis= null;
        try {
            fis = new FileInputStream("D:\\Java课后作业\\小组项目\\servers\\User.txt");
            if(fis.available()!=0){
                ois=new ObjectInputStream(fis);
                ArrayList list=(ArrayList) ois.readObject();
                this.listUser=list;
                return;
            }else {
                System.out.println("文件为空,请先注册!");
                return;

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }finally {
            try {
                ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
    //存储话题信息集合
    HashMap<String,Topic> mapTop=Setclass.mapTop;
    public void shuchuTop(){
        ObjectOutputStream oos=null;
        try {
            oos=new ObjectOutputStream(new FileOutputStream("D:\\Java课后作业\\小组项目\\servers\\Top.txt"));
            oos.writeObject(mapTop);
            //f=false;
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public void shuruTop(){
        ObjectInputStream ois=null;
        FileInputStream fis= null;

        try {
            fis = new FileInputStream("D:\\Java课后作业\\小组项目\\servers\\Top.txt");
            //当文件中的有内容时
            if(fis.available()!=0){
                ois=new ObjectInputStream(fis);
                HashMap<String,Topic> mapTop=(HashMap<String,Topic>) ois.readObject();
                this.mapTop=mapTop;
                return;
            }else {
                System.out.println("文件为空,请先注册!");
                //this.f=true;
                return;

            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }finally {
            try {
                //if (!f){
                ois.close();
                // }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
    //存储课程信息
    ArrayList<Course> list= Setclass.list;
    public void shuruCou(){
        ObjectInputStream ois=null;
        FileInputStream fis= null;

        try {
            fis = new FileInputStream("D:\\Java课后作业\\小组项目\\servers\\Cou.txt");
            if(fis.available()!=0){
                ois=new ObjectInputStream(fis);
                ArrayList list=(ArrayList) ois.readObject();
                this.list=list;
                return;
            }else {
                System.out.println("文件为空,请先注册!");
                return;

            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }finally {
            try {
                //if (!f){
                ois.close();
                // }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
    public void shuchuCou(){
        ObjectOutputStream oos=null;
        try {
            //创建文件
            oos=new ObjectOutputStream(new FileOutputStream("D:\\Java课后作业\\小组项目\\servers\\Cou.txt"));
            oos.writeObject(list);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    //存储用户订阅课程信息 键：用户名称 值：已经对应的课程集合类
    HashMap<String ,ArrayList<Course>> mapUser=Setclass.map;
    public void shuchuMapuse(){
        ObjectOutputStream oos=null;
        try {
            oos=new ObjectOutputStream(
                    new FileOutputStream(new File("D:\\Java课后作业\\小组项目\\servers\\Mapuser.txt")));
            oos.writeObject(mapUser);
            //f=false;
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public void shuruMapuse(){
        ObjectInputStream ois=null;
        FileInputStream fis= null;
        try {
            fis = new FileInputStream("D:\\Java课后作业\\小组项目\\servers\\Mapuser.txt");
            //当文件中的有内容时
            if(fis.available()!=0){
                ois=new ObjectInputStream(fis);
                HashMap<String ,ArrayList<Course>> map=(HashMap<String ,ArrayList<Course>>) ois.readObject();
                this.mapUser= map;
                return;
            }else {
                System.out.println("文件为空,请先注册!");
                //this.f=true;
                return;

            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }finally {
            try {
                //if (!f){
                ois.close();
                // }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }


    // 登入菜单
    public void oneMenu() {
        Scanner input=new Scanner(System.in);
        boolean flag=false;
        do {
            System.out.println("1.登入");
            System.out.println("2.注册");
            System.out.println("3.退出");
            switch (input.nextInt()){
                case 1:
                    // 登入
                    dengru();
                    break;
                case 2:
                    // 注册
                    zhuce();
                    oneMenu();
                    break;
                case 3:
                    //退出
                    System.out.println("欢迎下次使用");
                    return;
                default:
                    //输入其他的显示重新输入
                    System.out.println("请重新输入");
                    flag=true;
                    break;
            }
        }while (flag);
    }

    //注册
    public void zhuce(){
        System.out.println("请输入你的昵称：");
        String name=input.next();
        System.out.println("请输入你的密码:");
        String mima=input.next();
        System.out.println("请再次输入你的密码:");
        String mima1=input.next();
        if (mima.equals(mima1)){
            for (User use:listUser) {
                if (use.getName().equals(name)){
                    System.out.println("游戏昵称已经注册，重新输入");
                    return;
                }
            }
            Date date=new Date();
            User user=new User(name,mima);
            listUser.add(user);
            shuchuUser();
            System.out.println("你的昵称："+name+"您的密码为："+mima);
            System.out.println("注册成功");
        }else {
            System.out.println("输入的两次密码不同，请重新输入");
            return;
        }

    }

    //登入
    public void dengru(){
        //读取
        shuruUser();
        boolean flag=false;
        do {
            System.out.println("请输入昵称：");
            String name=input.next();
            System.out.println("请输入你的密码");
            String mima=input.next();
            for (User user:listUser){
                if ((user.getName().equals(name)&&user.getPassword().equals(mima))){
                    flag=true;
                    break;
                }
            }
            if (flag){
                System.out.println("登入成功");
                //执行里面下面的方法
                mainMenu(name);


            }else if(!flag){
                System.out.println("输入有误，请重新输入：");
            }
        }while (!flag);
    }

    // 主菜单
    public void mainMenu(String userName){
        boolean flag=false;
        do {
            System.out.println("***************欢迎使用德胜课堂APP****************");
            System.out.println("1.精品课程\n" + "2.订阅课程\n" + "3.课堂部落\n" + "4.我的账户\n"+ "5.多人聊天\n" +
                    "6.退出");
            System.out.println("请选择：");
            switch (input.nextInt()){
                case 1:
                    //1.精品课程
                    firstMenu(userName);
                    break;
                case 2:
                    //2.订阅课程
                    sub(userName);
                    break;
                case 3:
                    //3.课堂部落
                    threeMain(userName);
                    break;
                case 4:
                    //4.我的账户
                    fourMain(userName);
                    break;
                case 5:
                    //退出
                    talkRoom();
                    break;
                case 6:
                    //
                    System.out.println("欢迎下次使用");
                    System.exit(0);
                default:
                    //
                    flag=true;
                    System.out.println("请重新输入");
                    break;
            }
        }while (flag);

    }



    //1.精品课程 2级菜单
    public void firstMenu(String userName){
        boolean flag=false;
        do {
            System.out.println("1.物理\n" + "2.化学\n" + "3.语文\n" +
                    "4.英语\n" + "5.数学\n" + "6.生物\n"+ "7.返回上一级\n");
            System.out.println("请选择您要学习的课程编号：");
            switch (input.nextInt()){
                case 1:
                    //
                    judge1(userName);
                    break;
                case 2:
                    //
                    judge2(userName);
                    break;
                case 3:
                    //
                    judge3(userName);
                    break;
                case 4:
                    //
                    judge4(userName);
                    break;
                case 5:
                    //
                    judge5(userName);
                    break;
                case 6:
                    //
                    judge6(userName);
                    break;
                case 7:
                    // 放回
                    mainMenu(userName);
                    break;
                default:
                    //
                    flag=true;
                    System.out.println("请重新输入");
                    break;
            }
        }while (flag);
    }

    //1.精品课程 2级菜单  下方法： 判断课程类型 显示相应课程
    public void judge1(String userName){
        // 循环遍历显示
        for (Course course:list){
            if (course.getType().equals("物理")){
                System.out.println(course.getName() +"  "+course.getAuthor() );
            }
        }
        //判断选择的课程是下载还是订阅
        chose(userName);
    }
    public void judge2(String userName){
        for (Course course:list){
            if (course.getType().equals("化学")){
                System.out.println(course.getName() +"  "+course.getAuthor() );
            }
        }
        chose(userName);
    }
    public void judge3(String userName){
        for (Course course:list){
            if (course.getType().equals("语文")){
                System.out.println(course.getName() +"  "+course.getAuthor() );
            }
        }
        chose(userName);
    }
    public void judge4(String userName){
        for (Course course:list){
            if (course.getType().equals("英语")){
                System.out.println(course.getName() +"  "+course.getAuthor() );
            }
        }
        chose(userName);
    }
    public void judge5(String userName){
        for (Course course:list){
            if (course.getType().equals("数学")){
                System.out.println(course.getName() +"  "+course.getAuthor() );
            }
        }
        chose(userName);
    }
    public void judge6(String userName){
        for (Course course:list){
            if (course.getType().equals("生物")){
                System.out.println(course.getName() +"  "+course.getAuthor() );
            }
        }
        chose(userName);
    }


    //判断选择的课程是下载还是订阅
    public void chose(String userName){

        boolean flag=false;
        do {
            System.out.println("请您选择：  1.下载    2.订阅");
            switch (input.nextInt()){
                case 1:
                    //
                    download();
                    break;
                case 2:
                    //
                    subscription(userName);
                    break;
                default:
                    //
                    flag=true;
                    System.out.println("请重新输入");
                    break;
            }
            mainMenu(userName);
        }while (flag);
    }
    //创建文件
    public File createFile(String subpath){
        File file=new File("D:\\Java课后作业\\小组项目\\txt",subpath);
        return file;
    }
    //下载
    public void download(){
        System.out.println("请输入你选择的课程名称：");
        String courseName=input.next();
        for (Course course:list){
            if (course.getName().equals(courseName)){
                //拿到课程，执行下载或者订阅 ，所以把这个课程对象course 做为参数，把他序列化
                shuchu(course.getName());
                System.out.println("下载成功");
                return;
            }
        }
    }

    //序列化 下载对象
    public void shuchu(String course){
        ObjectOutputStream oos=null;
        try {
            //创建文件
            File file =createFile(course);
            oos=new ObjectOutputStream(new FileOutputStream(file));
            oos.writeObject(list);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    //反序列化 上传对象
    public void shuru(String subpath){
        ObjectInputStream ois=null;
        FileInputStream fis= null;

        try {
            fis = new FileInputStream(subpath);
            //当文件中的有内容时
            if(fis.available()!=0){
                ois=new ObjectInputStream(fis);
                ArrayList list=(ArrayList) ois.readObject();
                this.list=list;
                return;
            }else {
                System.out.println("文件为空,请先注册!");
                //this.f=true;
                return;

            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }finally {
            try {
                //if (!f){
                ois.close();
                // }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    //订阅
    public void subscription(String userName){
        shuruCou();
        System.out.println("请输入你选择的课程名称：");
        String courseName=input.next();
        for (Course course:list){
            if (course.getName().equals(courseName)){
                //拿到课程，执行下载或者订阅 ，所以把这个课程对象course 做为参数，把他序列化
                //遍历mapuser集合 判断是否存在这个使用者；没有就创建集合
                for (String name:mapUser.keySet()){
                    if (name.equals(userName)){
                        ArrayList list=mapUser.get(name);
                        list.add(course);
                    }else {
                        ArrayList list1=creatMap(course);
                        mapUser.put(userName,list1);
                    }
                }
                shuchuMapuse();
            }
        }
        System.out.println("订阅成功！");
        mainMenu(userName);
    }
    // 创建集合
    public ArrayList<Course> creatMap(Course course){
        ArrayList arrayList=new ArrayList();
        arrayList.add(course);
        return arrayList;
    }

    //主菜单：订阅课程
    public void sub(String username){
        shuruMapuse();

        ArrayList<Course> listss=mapUser.get(username);
        for (Course str:listss){
            System.out.println(str.getName());
        }
        //订阅取消   和   下载
        System.out.println("1.取消订阅   2.下载");
        switch (input.nextInt()){
            case 1:
                System.out.println("请输入你要取消订阅的课程");
                String name=input.next();

                for (Course str:listss){
                    if (str.getName().equals(name)){
                        listss.remove(str);
                        shuchuMapuse();
                        System.out.println("取消成功！");
                    }
                }
                break;
            case 2:
                // 下载
                download();
                break;
            default:
                //
                break;

        }
        mainMenu(username);
    }

    //菜单 3部落
    public void threeMain(String name){
        shuruTop();
        for (Topic topic:mapTop.values()){
            System.out.println("话题编号："+topic.getId()+"   "+topic.getName());
        }
        //首先遍历输出所有的课堂部落信息：（所有人发表的），用两个集合存储，一个存储所有，一个存储诗人

        System.out.println("1.创建话题  2.加入话题");
        switch (input.nextInt()){
            case 1:
                //
                createTopic(name);
                return;
            case 2:
                //
                join(name);
                break;
            default:
                //退出
                return;
        }
    }

    //创建部落
    public void createTopic(String name){
        System.out.println("请输入你的话题名称：");
        String nameTopic=input.next();
        String id=createid();
        Topic  topic=new Topic(id,nameTopic,name);
        //把话题存入集合
        mapTop.put(topic.getId(),topic);
        //系列化
        shuchuTop();
        System.out.println("创建成功");
        mainMenu(name);

    }

    //加入部落
    public void join(String useName){
        //序列化
        shuruTop();
        System.out.println("请输入你要加入的话题部落的id号：");
        String id=input.next();
        for (Topic topic:mapTop.values()){
            if (topic.getId().equals(id)){
                //调入方法
                comment(id,useName);
            }
        }

    }

    //点赞方法
    public void addOk(String id){
        Topic topic=mapTop.get(id);
        topic.setNumOk(topic.getNumOk()+1);
        shuchuTop();
    }

    //方法评论
    public void comment(String id,String useName){
        shuruCom();
        Topic topic=mapTop.get(id);
        System.out.println("话题："+topic.getName()
                +"\t作者："+topic.getAuthor()+"\t\t点赞数："
                +topic.getNumOk()+"话题id："+topic.getId());
        //遍历输出说有的评论，在最后可以追加评论：
        for (Comments comments:listcom){
            if (comments.getId().equals(id)){
                System.out.println(comments.getComName()+"  :"+comments.getComment()+"   "+comments.getTime());
            }
        }
        System.out.print(useName+":");
        String nierong=input.next();
        Date date=new Date();
        Comments comments=new Comments(id,useName,nierong,date);
        listcom.add(comments);
        shuchuCom();
        comment(id,useName);
    }

    //登录id要求生成随机6位数字
    public String createid(){
        Random random=new Random();
        StringBuffer sb=new StringBuffer();
        for (int i = 0; i <6 ; i++) {
            int num=random.nextInt(10);
            sb.append(num);
        }
        String a=sb.toString();
        //int num1=Integer.parseInt(a);
        return a;
    }

    //菜单4  我的菜单
    public void fourMain(String name){
        System.out.println("1.显示账户信息 ");
        System.out.println("2.修改账户： ");
        switch (input.nextInt()){
            case 1:
                //
                show(name);
                break;
            case 2:
                //
                change(name);
                break;
            default:
                //
                break;
        }
        mainMenu(name);
    }

    //显示客户信息
    public void show(String name){
        shuruUser();
        for (User user:listUser) {
            if (user.getName().equals(name)) {
                System.out.println("名称：" + user.getName() + "     密码：" + user.getPassword());
                break;
            }
        }
    }

    //修改账户
    public void change(String name){
        shuruUser();
        boolean fs=false;
        System.out.println("请输入你的新名称：");
        String names=input.next();
        System.out.println("请输入你的新密码：");
        String mima=input.next();
        for (User user:listUser){
            if (user.getName().equals(names)){
                fs=true;
                break;
            }
        }
        if (fs){
            System.out.println("你输入的名称已经存在：");
            return;
        }else if (!fs){
            for (User user:listUser){
                if (user.getName().equals(name)){
                    user.setName(names);
                    user.setPassword(mima);
                    System.out.println("修改成功！");
                    shuchuUser();
                    break;
                }
            }
        }
    }

    public void talkRoom() {
        try {
            Socket socket = new Socket("localhost",8888);
            new ThreadWriter(socket).start();
            new ThreadReader(socket).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
