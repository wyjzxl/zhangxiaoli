import java.io.Serializable;
import java.util.HashMap;

/**
 * Created by lchero on 2018/8/23.
 */
//所以要有一个话题类
//话题类属性： 话题名称  作者  点赞数   ，方法评论   ，方法： 点赞
////话题类属性： 话题名称  作者  点赞数   ，方法评论   ，方法： 点赞
public class Topic implements Serializable {
    private String id;  //话题编号
    private String name;
    private String author;
    private  int numOk=0;
    private HashMap comment;    // 评论

    public Topic(String id, String name, String author) {
        this.id = id;
        this.name = name;
        this.author = author;
    }

    public Topic(String name, String author) {
        this.name = name;
        this.author = author;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getNumOk() {
        return numOk;
    }

    public void setNumOk(int numOk) {
        this.numOk = numOk;
    }



}
