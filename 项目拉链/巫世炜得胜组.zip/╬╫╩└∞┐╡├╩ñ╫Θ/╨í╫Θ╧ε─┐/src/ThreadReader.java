import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class ThreadReader extends Thread {
    Socket socket;

    public ThreadReader(Socket socket) {
        this.socket = socket;
    }
    public void run(){
        try {
            while (true){
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                String str =(String) ois.readObject();
                System.out.println(str);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
