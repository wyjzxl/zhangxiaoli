import sun.reflect.generics.scope.Scope;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ServerThread extends Thread {
    Socket socket;
    ArrayList<Socket>list;
    ObjectInputStream ois ;
    ObjectOutputStream oos;

    public ServerThread(Socket socket, ArrayList<Socket> list) {
        this.socket = socket;
        this.list = list;
    }

    public void run(){
        try {
            while (true){
                ois = new ObjectInputStream(socket.getInputStream());
                String str = (String)ois.readObject();
                for (Socket socket:list){
                    if (this.socket!=socket){
                        oos = new ObjectOutputStream(socket.getOutputStream());
                        oos.writeObject(str);
                        oos.flush();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
