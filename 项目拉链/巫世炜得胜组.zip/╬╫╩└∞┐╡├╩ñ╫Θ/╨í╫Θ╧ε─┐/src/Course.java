import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by lchero on 2018/8/21.
 */
//课程类 ：属性  属性：名称 ，作者，课程类型
////方法： 下载，上传，订阅  内容
public class Course implements Serializable {
    private String name;
    private String author;
    private String type;  //课程类型
    private int state=0;  // 0已经订阅 1未订阅

    public Course(String name, String author, String type, int state) {
        this.name = name;
        this.author = author;
        this.type = type;
        this.state = state;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public Course() {}

    public Course(String name, String author, String type) {
        this.name = name;
        this.author = author;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}


/*
项目不足：
1.取消订阅处有个小bug没有修复。
2.下载数据后的格式编码问题。
3.重复代码量过多，怎么简化。
4.网络编程怎么加入进行数据交互问题。
5.数据传输过程中遇到的对象不匹配问题。
6.缺少一个上传功能。*/

/*

总结：
1.回顾了前期的知识点。
2.对集合，序列化，面向对象运用熟练。
3.对网络编程，xml，线程，三大块还有很多不懂的地方，后期需要加深。
4.对开发项目，有一定自己的见解。
5.自己不足的地方还有很多，需要提高。
*/
