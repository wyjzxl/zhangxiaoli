import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class ThreadWriter extends Thread {
    Socket socket;

    public ThreadWriter(Socket socket) {
        this.socket = socket;
    }

    public void run(){
        try {
            Scanner sc = new Scanner(System.in);
            while (true){
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                String str = sc.next();
                oos.writeObject(str);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
