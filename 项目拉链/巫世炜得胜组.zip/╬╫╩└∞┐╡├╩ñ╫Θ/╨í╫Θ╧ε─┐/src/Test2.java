public class Test2 {
    public static void main(String[] args) {
        Funtion funtion2 = new Funtion();
        funtion2.oneMenu();
    }
}
