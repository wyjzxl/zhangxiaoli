import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by lchero on 2018/8/21.
 */
public class Setclass  {
    //存储用户信息
     static ArrayList<User> listUser=new ArrayList<User>();

    //public static ArrayList<Course> arrayList =new ArrayList<Course>();
    //每个用户的下面 存储着一个带订阅信息的 ，
    //集合存储自己的订阅的信息
    public static HashMap<String ,ArrayList<Course>> map=new HashMap<String ,ArrayList<Course>>();
    //评论集合
    static ArrayList<Comments> listcom=new ArrayList<Comments>();


    //初始化
    public static ArrayList<Course> list=new ArrayList<Course>();
    static {
        ArrayList<Course> list1=new ArrayList<Course>();
        list1.add(new Course("高级物理课程","tom","物理",1));
        User user=new User("巫世炜","961203");
        map.put(user.getName(),list1);



        listUser.add(user);


        Course course=new Course("高级物理课程","tom","物理");
        Course course1=new Course("初中物理课程","joms","物理");
        Course course2=new Course("初中化学课程","初化","化学");
        Course course3=new Course("高中化学课程","quem","化学");
        Course course4=new Course("语文1","joms","语文");
        Course course5=new Course("语文2","joms","语文");
        Course course6=new Course("英语1","joms","英语");
        Course course7=new Course("英语2","joms","英语");
        Course course8=new Course("数学1","joms","数学");
        Course course9=new Course("数学2","joms","数学");
        Course course10=new Course("生物1","joms","生物");
        Course course11=new Course("生物2","joms","生物");
        list.add(course);
        list.add(course1);
        list.add(course2);
        list.add(course3);
        list.add(course4);
        list.add(course5);
        list.add(course6);
        list.add(course7);
        list.add(course8);
        list.add(course9);
        list.add(course10);
        list.add(course11);

    }

    static HashMap<String,Topic> mapTop =new HashMap<String,Topic>();
    static {
        Topic topic=new Topic("123456","我的话题","wushiwei");
        mapTop.put(topic.getId(),topic);
    }


    static {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        Comments com=null;
        try {
            com=new Comments("123456","wushiwei","神经病",sdf.parse("2018-8-23"));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        listcom.add(com);
    }

}
