/**
 * Created by lchero on 2018/8/21.
 */
public class Test {
    public static void main(String[] args) {
        Funtion funtion=new Funtion();
        funtion.oneMenu();
    }
}
