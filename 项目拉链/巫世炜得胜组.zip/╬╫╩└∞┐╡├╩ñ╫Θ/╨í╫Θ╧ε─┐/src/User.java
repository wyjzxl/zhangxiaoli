import java.io.Serializable;
import java.util.ArrayList;

/**


 */
public class User implements Serializable {
    private String name;  // 名称
    private String password; // 密码
    //private ArrayList<String> arrayList;  //存储；自己的订阅课程信息。
    //private ArrayList<> arrayList1;  // 存储自己的话题部落信息。名称




    public User() {
    }

    public User(String name, String password) {
        this.name = name;
        this.password = password;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}
