import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 服务器类
 */
public class MainServer {
    //主方法：启动服务器
    public static void main(String[] args) {

    }

    //创建服务器接口
    public void createrScoket(){
        try {
            ServerSocket socket=new ServerSocket(9612);
            do {
                //每次连接进入一个线程
                Socket sockets=socket.accept();
                ThreadSocket threadSocket=new ThreadSocket(sockets);
                threadSocket.start();

            }while (true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}