import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

/**
 * Created by lchero on 2018/8/22.
 */
public class ThreadSocket<T> extends Thread {

    private Socket socket;
    private T data;

    public ThreadSocket(Socket socket, T data) {
        this.socket = socket;
        this.data = data;
    }

    public ThreadSocket(Socket sockets) {

    }

   /* public ThreadSocket(Socket socket) {
        this.socket = socket;
    }*/

    //做之前服务器的事
    public void run(){
        try {
            synchronized (this){
                InputStream is=socket.getInputStream();
                OutputStream os=socket.getOutputStream();  // 通过socket 这个接口发送
                ObjectInputStream ois=new ObjectInputStream(is);
                T obj=(T)ois.readObject();
                //判断传输的是什么类型的文件，在执行相对于的操作方法。
                Class aClass= obj.getClass();
                String str=aClass.getName();



                //System.out.println("客户说："+user.getName()+user.getPwd());

                //获得客户端的ip信息
                InetAddress iss=socket.getInetAddress();
                String ip= iss.getHostAddress();
                System.out.println("客户端的ip："+ip);

                //给客户端一个相应
                String reply="欢迎登入";
                //通过输出流将响应发送回给客户端

                os.write(reply.getBytes());
                //释放相应的资源
                ois.close();
                os.close();
                is.close();
            }





        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }






}
