import java.util.Scanner;

/**
 * Created by lchero on 2018/8/22.
 */
public class Funtions {


}
