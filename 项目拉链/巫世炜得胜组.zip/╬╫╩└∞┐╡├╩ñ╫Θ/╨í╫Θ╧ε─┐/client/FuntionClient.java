import java.util.Scanner;

/**
 * Created by lchero on 2018/8/22.
 */
public class FuntionClient {
    Scanner input=new Scanner(System.in);
    MainClient client=new MainClient();
    // 登入菜单
    public void mainMune() {
        Scanner input=new Scanner(System.in);
        boolean flag=false;
        do {
            System.out.println("1.登入");
            System.out.println("2.注册");
            switch (input.nextInt()){
                case 1:
                    //登入
                    System.out.println("请输入您的名称或者账号：");
                    String name=input.next();
                    System.out.println("请输入你的密码：");
                    String password=input.next();
                    client.creatClientSocket(name,password);
                    break;
                case 2:
                    //
                    break;
                default:
                    //输入其他的显示重新输入
                    System.out.println("请重新输入");
                    flag=true;
                    break;
            }
        }while (flag);
    }
}
