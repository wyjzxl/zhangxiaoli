import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * Created by lchero on 2018/8/22.
 */
public class MainClient {
    User user=null;
    //创建接口
    public void creatClientSocket(String name ,String password){
        try {
            Socket socket=new Socket("localhost",9612);
            //发送
            OutputStream os=socket.getOutputStream();
            //接收
            InputStream is=socket.getInputStream();
            ObjectOutputStream oos=new ObjectOutputStream(os);
            user=new User(name,password);
            oos.writeObject(user);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
