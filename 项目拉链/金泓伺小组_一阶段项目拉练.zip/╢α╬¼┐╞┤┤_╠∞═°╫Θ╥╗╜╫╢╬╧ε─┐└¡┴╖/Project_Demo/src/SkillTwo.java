/**
 * Created by 木鬼 on 2018/8/22.
 * 技能三：诸神黄昏接口
 */
public interface SkillTwo {
    public void att2(Role role,Monsters monsters)throws Exception;
}
