import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * Created by Administrator on 2018/8/23.
 * 客户端
 */
public class KehuFankui {
    public void wanJia() {
        Scanner input=new Scanner(System.in);
        //快递点端口

            try {
                do {
                    Socket socket = new Socket("localhost", 8800);
                    //打开输出流
                    OutputStream os = socket.getOutputStream();
                    //输出
                    System.out.println("您的反馈我们会及时处理，请输入您的问题：");
                    String info = input.next();
                    os.write(info.getBytes());
                    socket.shutdownOutput();
                    //接收服务端回复
                    InputStream is = socket.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String reply = null;
                    while ((reply = br.readLine()) != null) {
                        System.out.println("逗比客服回应：" + reply);
                    }
                    //关闭流
                    os.close();
                    socket.close();
                    return;
                } while (true);
            } catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

