import java.io.Serializable;
import java.util.List;

/**
 * Created by 83976 on 2018/8/22.
 * 用户类
 */
public class User implements Serializable {
    private String id;      //账号
    private String paw;      //密码
//    private Role role;      //角色
    private List<Role> list;      //角色

    public User(String id, String paw1) {
    }
    public User(String id, String paw, List<Role> list) {
        this.id = id;
        this.paw = paw;
        this.list = list;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getPaw() {
        return paw;
    }
    public void setPaw(String paw) {
        this.paw = paw;
    }
    public List<Role> getList() {
        return list;
    }
    public void setList(List<Role> list) {
        this.list = list;
    }
}
