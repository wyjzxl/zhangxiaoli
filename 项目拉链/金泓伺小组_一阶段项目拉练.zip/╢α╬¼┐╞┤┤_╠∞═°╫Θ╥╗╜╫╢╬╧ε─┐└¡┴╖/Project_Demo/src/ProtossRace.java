import org.junit.Test;

import java.io.Serializable;

/**
 * Created by 木鬼 on 2018/8/22.
 * 神族
 */
public class ProtossRace extends Race implements SkillOne,SkillTwo,SkillThree,Serializable{
    private String name;  //种族名称
    public ProtossRace(String name) {
        super();
        this.name=name;
    }
    public ProtossRace() {
        this.hp=100;
        this.att=8;
        this.def=2;
        this.mp=80;
        this.name="神族";
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    @Override
    public void info() {
        System.out.println("神族：");
        System.out.println("  血量值："+this.hp+"  魔法值："+this.mp+"  攻击力："+this.att+"  防御力："+this.def);
    }
    @Override
    //普通攻击
    @Test
    public void att(Role role, Monsters monsters) {
        monsters.setHp((monsters.getHp() - (role.getAtt() - monsters.getDef())));
        System.out.println("王八拳！！！！       怪兽生命值降低" + ((int)(role.getAtt()*0.8 - monsters.getDef())) + "点！"+"目前怪兽还有"+monsters.getHp()+"点血量");
    }
    @Override
    //技能一：大力出奇迹
    public void att1(Role role, Monsters monsters) throws Exception {
        if (role.getCurrentMp() >= 10) {
            System.out.println("魔法值只够你使用大力出奇迹！用点力吧少年");
            role.setCurrentMp(role.getCurrentMp() - 10);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 1.2) - monsters.getDef())));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName() + "使用了大力出奇迹，对怪兽造成了"
                    + (int) (role.getAtt() * 1.2 - monsters.getDef()) + "点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        } else {
            System.out.println("魔法值不够！魔法值不够！");
            System.out.println("本次将使用王八券攻击！");
            att(role, monsters);
        }
    }
    @Override
    //技能二：洪荒之力
    public void att3(Role role, Monsters monsters) throws Exception {
        if (role.getCurrentMp() >= 20) {
            role.setCurrentMp(role.getCurrentMp() - 20);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 1.8) - monsters.getDef())));
            System.out.println(role.getName() + "使用了洪荒之力，系哩啪啦系哩啪啦的对怪兽造成了"
                    + (int) (role.getAtt() * 1.8 - monsters.getDef()) + "点伤害！");
        }else if (role.getCurrentMp() >= 10) {
            System.out.println("魔法值只够你使用大力出奇迹！用点力吧少年");
            role.setCurrentMp(role.getCurrentMp() - 10);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 1.5) - monsters.getDef())));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName() + "使用了大力出奇迹，对怪兽造成了"
                    + (int) (role.getAtt() * 1.5 - monsters.getDef()) + "点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        } else {
            System.out.println("魔法值不够！魔法值不够！");
            System.out.println("本次将使用王八券攻击！");
            att(role, monsters);
        }
    }
    @Override
    //技能三：诸神黄昏
    public void att2(Role role, Monsters monsters) throws Exception {
        if (role.getCurrentMp() >= 30) {
            role.setCurrentMp(role.getCurrentMp() - 30);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 2.0) - monsters.getDef())));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName() + "使用了洪荒之力，系哩啪啦系哩啪啦的对怪兽造成了"
                    + (int) (role.getAtt() * 2.0 - monsters.getDef()) + "点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        }else if (role.getCurrentMp() >= 20) {
            System.out.println("魔法值不够了了了了了！憋住你的屁，快用洪荒之力！");
            role.setCurrentMp(role.getCurrentMp() - 20);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 1.8 - monsters.getDef()))));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName() + "使用了洪荒之力，系哩啪啦系哩啪啦的对怪兽造成了"
                    + (int) (role.getAtt() * 1.8 - monsters.getDef()) + "点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        }else if (role.getCurrentMp() >= 10) {
            System.out.println("魔法值只够你使用大力出奇迹！用点力吧少年");
            role.setCurrentMp(role.getCurrentMp() - 10);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 1.5) - monsters.getDef())));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName() + "使用了大力出奇迹，对怪兽造成了"
                    + (int) (role.getAtt() * 1.5 - monsters.getDef()) + "点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        } else {
            System.out.println("魔法值不够！魔法值不够！");
            System.out.println("本次将使用王八券攻击！");
            att(role, monsters);
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println("目前怪兽还有"+monsters.getHp()+"点血量");
        }
    }
}
