import java.io.Serializable;

/**
 * Created by 木鬼 on 2018/8/22.
 * 怪兽攻击场景类
 */
public class Scene implements Serializable {
    private String type;           //攻击类型
    private String describe;      //攻击描述
    public Scene() {
    }
    public Scene(String type, String describe) {
        this.type = type;
        this.describe = describe;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getDescribe() {
        return describe;
    }
    public void setDescribe(String describe) {
        this.describe = describe;
    }
}
