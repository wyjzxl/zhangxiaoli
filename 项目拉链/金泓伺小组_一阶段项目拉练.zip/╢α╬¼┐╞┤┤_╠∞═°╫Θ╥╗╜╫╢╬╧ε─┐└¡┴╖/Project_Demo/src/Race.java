import java.io.Serializable;

/**
 * Created by 83976 on 2018/8/22.
 * 种族类
 */
public abstract class Race implements Serializable {
    protected int hp;     //血量值
    protected int att;    //攻击力
    protected int def;    //防御力
    protected int mp;     //魔力值
    public int getHp() {
        return hp;
    }
    public void setHp(int hp) {
        this.hp = hp;
    }
    public int getAtt() {
        return att;
    }
    public void setAtt(int att) {
        this.att = att;
    }
    public int getDef() {
        return def;
    }
    public void setDef(int def) {
        this.def = def;
    }
    public int getMp() {
        return mp;
    }
    public void setMp(int mp) {
        this.mp = mp;
    }

    public abstract void info();
    public abstract void att(Role role,Monsters monsters);
}
