import java.io.Serializable;

/**
 * Created by 木鬼 on 2018/8/22.
 * 魔族类
 */
public class DemonRace extends Race implements SkillOne,Serializable {
    private String name; //种族名称
    public DemonRace(String name) {
        super();
        this.name=name;
    }
    public DemonRace() {
        this.hp=100;
        this.att=12;
        this.def=4;
        this.mp=20;
        this.name="魔族";
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    @Override
    public void info() {
        System.out.println("魔族：");
        System.out.println("  血量值："+this.hp+"  魔法值："+this.mp+"  攻击力："+this.att+"  防御力："+this.def);
    }
    @Override
    //普通攻击
    public void att(Role role, Monsters monsters) {
        monsters.setHp((int) (monsters.getHp()-(role.getAtt()*1.2-monsters.getDef())));
        if(monsters.getHp()<0){
            monsters.setHp(0);
        }
        System.out.println("一记老魔拳把你打得飞起*******怪兽生命值降低"+((int)(role.getAtt()*1.2-monsters.getDef()))+"点！"+"目前怪兽还有"+monsters.getHp()+"点血量");
    }
    @Override
    //技能一：大力出奇迹
    public void att1(Role role,Monsters monsters) throws Exception {
        if (role.getCurrentMp()>=10){
            role.setCurrentMp(role.getCurrentMp()-10);
            monsters.setHp((int) (monsters.getHp()-((role.getAtt()*1.2*1.2)-monsters.getDef())));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName()+"使用了大力出奇迹*******对怪兽造成了"+(int)(role.getAtt()*1.2-monsters.getDef())+"点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        }else {
            System.out.println("魔法值不够！魔法值不够！");
            System.out.println("本次将使用老魔拳攻击！");
            att(role,monsters);
        }
    }
}
