import org.junit.Test;

import java.io.*;
import java.util.*;

/**
 * Created by 木鬼 on 2018/8/22.
 * 操作类
 */
public class Opera {
    Scanner input=new Scanner(System.in);
    Map<String,User>userMap=Info.userMap;
    List<Role> roleList=Info.roleList;
    List<Scene>sceneList=Info.sceneList;
    KehuFankui o=new KehuFankui();
    //一级菜单
    public void menu1(){
        do {
            System.out.println("                 ****^****");
            System.out.println("             ********|*******");
            System.out.println("       *******-== G A M E ==-*******");
            System.out.println("*************欢迎登陆 逗比的世界*************");
            System.out.println("***1、登陆 * 2、注册 * 3、游戏试玩 * 4、退出***");
            System.out.println(" ****************************************");
            System.out.println("  *************本周最火小游戏*************");
            System.out.println(" ");
            System.out.println("            ^^");
            System.out.println("           |||");
            System.out.println(" 888     88888888888888888888888888888888888/ ");
            System.out.println("8888888888888888888888888888888888888888888/       >>>请选择：");
            System.out.println(" 888     888888888888888888888888888888888/              ");
            System.out.println("           |||");
            System.out.println("            vv");
            int choice=input.nextInt();
            switch (choice){
                case 1:
                    System.out.print("请输入账号：");
                    String id=input.next();
                    System.out.print("请输入密码：");
                    String paw=input.next();
                    if (landing(id,paw)==true){
                        choice(id);
                    }else {
                        System.out.println("输入有误！");
                    }
                    break;
                case 2:
                    register();
                    break;
                case 3:
                    String tId="123";
                    choice(tId);
                    break;
                case 4:
                    System.out.println("感谢使用此程序！");
                    return;
                default:
                    System.out.println("请选择正确的选项！");
            }
        } while (true);
    }
    //用户序列化
    public void userSerialize(){
        ObjectOutputStream oos=null;
        try {
            oos=new ObjectOutputStream(new FileOutputStream("用户.txt"));
            oos.writeObject(userMap);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (oos!=null){
                try {
                    oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    //用户反序列化
    public void unUserSerialize(){
        ObjectInputStream ois=null;
        File file=new File("用户.txt");
        if (file.exists()) {
            try {
                ois = new ObjectInputStream(new FileInputStream(file));
                userMap = (Map<String,User>) ois.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                if (ois != null) {
                    try {
                        ois.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
    //注册
    public void register(){
        unUserSerialize();
        System.out.print("请输入您的账号：");
        String id=input.next();
        for (String key:userMap.keySet()){
            if (key.equals(id)){
                System.out.println("此账号已被注册！");
                return;
            }
        }
        boolean flag=false;
        String paw1;
        String paw2;
        do {
            System.out.print("请输入您的密码：");
            paw1=input.next();
            System.out.print("请再次输入您的密码：");
            paw2=input.next();
            if (paw1.equals(paw2)){
                flag=true;
            }else {
                System.out.println("两次输入的密码不同，请重新输入！");
            }
        } while (flag==false);
        System.out.print("请创造您第一个角色：");
        Race race = null;
        System.out.print("请输入昵称：");
        String name=input.next();
        boolean flag1=false;
        do {
            System.out.println("1、人族  2、神族  3、魔族");
            System.out.print("请选择种族：");
            int choice=input.nextInt();
            switch (choice){
                case 1:
                    race=new HumanRace();
                    flag1=true;
                    break;
                case 2:
                    race=new DemonRace();
                    flag1=true;
                    break;
                case 3:
                    race=new ProtossRace();
                    flag1=true;
                    break;
                default:
                    System.out.println("请选择正确的选项");
                    break;
            }
        } while (flag1==false);
        List<Role>roleList=new ArrayList<>();
        Role role=new Role(id,name,race,race.att,race.def,race.hp,race.hp,race.mp,race.mp,100);
        roleList.add(role);
        User user=new User(id,paw1,roleList);
        userMap.put(id,user);
        userSerialize();
        choice(id);
    }
    //登陆
    public boolean landing(String id,String paw){
        unUserSerialize();
        boolean flag=false;
        for (String key:userMap.keySet()){
            if (key.equals(id)&&userMap.get(key).getPaw().equals(paw)){
                flag=true;
            }
        }
        return flag;
    }
    //选择角色
    public void choice(String id){
        unUserSerialize();
        do {
            int i=0;
            for (String key:userMap.keySet()){
                if (key.equals(id)){
                    for (Role role:userMap.get(key).getList()){
                        i++;
                        System.out.println(i+". 昵称："+role.getName()+" 血量值："+role.getHp()+" 剩余血量："+role.getCurrentHp()
                        +" 魔力值："+role.getMp()+" 剩余魔力："+role.getCurrentMp()+" 攻击力："+role.getAtt()
                        +" 防御力："+role.getDef()+" 金币："+role.getGold());
                    }
                }
            }
            System.out.print("请选择角色，按4创建新角色,按0退出界面（最多创建三个角色）：");
            int choice=input.nextInt();
            int num=userMap.get(id).getList().size();
            Role role=null;
            roleList=userMap.get(id).getList();
            switch (choice){
                case 1:
                    if (num>=1){
                        role=roleList.get(0);
                        menu2(role);
                    }else {
                        System.out.println("您还未创建角色！");
                    }
                    break;
                case 2:
                    if (num>=2){
                        role=roleList.get(1);
                        menu2(role);
                    }else {
                        System.out.println("您还未拥有第二个角色！");
                    }
                    break;
                case 3:
                    if (num>=3){
                        role=roleList.get(2);
                        menu2(role);
                    }else {
                        System.out.println("您还未拥有第三个角色！");
                    }
                    break;
                case 4:
                    if (num<3) {
                        gor(id);
                    }else {
                        System.out.println("您的角色已达上限，不可创建！");
                    }
                    break;
                case 0:
                    return;
                default:
                    System.out.println("请选择正确的选项");
                    break;
            }
        } while (true);
    }
    //创造角色
    public void gor(String id){
        Race race = null;
        System.out.print("请输入昵称：");
        String name=input.next();
        boolean flag=false;
        do {
            System.out.println("1、人族  2、神族  3、魔族");
            System.out.print("请选择种族：");
            int choice=input.nextInt();
            switch (choice){
                case 1:
                   race=new HumanRace();
                    flag=true;
                    break;
                case 2:
                    race=new DemonRace();
                    flag=true;
                    break;
                case 3:
                    race=new ProtossRace();
                    flag=true;
                    break;
                default:
                    System.out.println("请选择正确的选项");
                    break;
            }
        } while (flag==false);
        Role role=new Role(id,name,race,race.att,race.def,race.hp,race.hp,race.mp,race.mp,100);
        roleList.add(role);
        userSerialize();
    }
    //二级菜单
    public void menu2(Role role){
        do {
            System.out.println("1、开始游戏  2、游戏商城  3、人物属性   4、看广告得金币 5、猜大小得金币 6、咨询客服 7、充值 8、返回上一页");
            int xuan = input.nextInt();
            switch (xuan) {
                case 1:
                    GameMenu(role);
                    break;
                case 2:
                    shop(role);
                    break;
                case 3:
                    renwu(role);
                    break;
                case 4:
                    ad(role);
                    break;
                case 5:
                    jinbi(role);
                    break;
                case 6:
                    o.wanJia();
                    break;
                case 7:
                    chong(role);
                    break;
                case 8:
                    return;
            }
        }while (true);
    }
    //增加显示怪物当前血量
    public void GameMenu(Role role){
        System.out.println("请选择副本难度模式：");
        System.out.print("1、入门难度 2、菜鸟难度 3、高手难度 4、骨灰难度 5、退出");
        int choice=input.nextInt();
        switch(choice){
            case 1:
                System.out.print("1、入门难度");
                Monsters m1=new Monsters(20,10,5,1);
                play(role,m1);
                break;
            case 2:
                System.out.print("2、菜鸟难度");
                Monsters m2=new Monsters(50,30,15,10);
                play(role,m2);
                break;
            case 3:
                System.out.print("3、高手难度");
                Monsters m3=new Monsters(200,60,40,20);
                play(role,m3);
                break;
            case 4:
                System.out.print("4、骨灰难度");
                Monsters m4=new Monsters(5000,200,100,60);
                play(role,m4);
                break;
            case 5:
                System.out.println("退出选择");
                return;
            default:
                System.out.println("输入有误，请重新输入！");
                break;
        }
    }

    public void play(Role role,Monsters monster){
        System.out.println("游戏开始！");
        for (int i = 0; i < roleList.size(); i++) {
            if(role.getRace() instanceof DemonRace){
                playDemon(role,monster);
                break;
            }
            if(role.getRace() instanceof HumanRace){
                playHuman(role,monster);
                break;
            }
            if(role.getRace() instanceof ProtossRace){
                playProtoss(role,monster);
                break;
            }
        }
    }
    //恶魔类游戏副本
    public void playDemon(Role role,Monsters monster) {
        System.out.println("黑暗中出现一个怪物:\t\t血量"+monster.getHp()+".攻击力"+monster.getAtt()+".防御力"+monster.getDef());
        do {
            Random random=new Random();
            int opps=random.nextInt(4);
            System.out.println("*************************");
            System.out.print("1、普通攻击 2、特殊技能1号 3、逃跑：");
            int choice = input.nextInt();
            countDown();
            switch (choice) {
                case 1:
                    new DemonRace().att(role, monster);
                    if(monster.getHp()<=0){
                        System.out.println("干的漂亮！");
                        System.out.println("怪物的口袋中闪闪发光.....");
                        outComes(role,monster);
                        return;
                    }
                    break;
                case 2:
                    new DemonRace().att(role, monster);
                    if(monster.getHp()<=0){
                        System.out.println("干的漂亮！");
                        System.out.println("怪物的口袋中闪闪发光.....");
                        outComes(role,monster);
                        return;
                    }
                    break;
                case 3:
                    System.out.println("打得好，我认输！");
                    return;
                default:
                    System.out.println("你说啥？我没带眼镜听不见!");
                    break;
            }
            for (int i = 0; i < sceneList.size(); i++) {                            //随机生成怪物回馈场景
                System.out.println("*************************");
                System.out.println("肉山大魔王嘴里嘀咕着什么...");
                System.out.println(sceneList.get(opps).getType()+"!随着技能来袭:"+sceneList.get(opps).getDescribe());
                role.setCurrentHp((role.getCurrentHp() - (monster.getAtt() * 1 - role.getDef())));
                countDown();
                if(role.getCurrentHp()<0){
                    role.setCurrentHp(0);
                }
                System.out.println("\t\t\t\t\t\t\t\t\t\t"+role.getName()+"血量下降:"+((monster.getAtt() * 1 - role.getDef()))+"点，目前健康值:"+role.getCurrentHp());
                if (role.getCurrentHp() <= 0) {
                    System.out.println("老衲这一生....值了！");
                    return;
                }
                break;
            }
        } while (true);
    }
    //人类游戏副本
    public  void playHuman(Role role,Monsters monster){
        System.out.println("黑暗中出现一个怪物:\t\t血量"+monster.getHp()+".攻击力"+monster.getAtt()+".防御力"+monster.getDef());
        do {
            Random random=new Random();
            int opps=random.nextInt(4);
            System.out.println("*************************");
            System.out.print("1、普通攻击 2、特殊技能1号 3、特殊技能2号 4、逃跑：");
            int choice=input.nextInt();
            countDown();
            switch (choice){
                case 1:
                    new HumanRace().att(role,monster);
                    if(monster.getHp()<=0){
                        System.out.println("干的漂亮！");
                        System.out.println("怪物的口袋中闪闪发光.....");
                        outComes(role,monster);
                        return;
                    }
                    break;
                case 2:
                    try {
                        new HumanRace().att1(role,monster);
                        if(monster.getHp()<=0){
                            System.out.println("干的漂亮！");
                            System.out.println("怪物的口袋中闪闪发光.....");
                            outComes(role,monster);
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    try {
                        new HumanRace().att2(role,monster);
                        if(monster.getHp()<=0){
                            System.out.println("干的漂亮！");
                            System.out.println("怪物的口袋中闪闪发光.....");
                            outComes(role,monster);
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 4:
                    System.out.println("打得好，我认输！");
                    return;
                default:
                    System.out.println("你说啥？我没带眼镜听不见!");
                    break;
            }
            for (int i = 0; i < sceneList.size(); i++) {                            //随机生成怪物回馈场景
                System.out.println("*************************");
                System.out.println("肉山大魔王嘴里嘀咕着什么...");
                System.out.println(sceneList.get(opps).getType()+"!随着技能来袭:"+sceneList.get(opps).getDescribe());
                role.setCurrentHp((role.getCurrentHp() - (monster.getAtt() * 1 - role.getDef())));
                countDown();
                if(role.getCurrentHp()<0){
                    role.setCurrentHp(0);
                }
                System.out.println("\t\t\t\t\t\t\t\t\t\t"+role.getName()+"血量下降:"+((monster.getAtt() * 1 - role.getDef()))+"点，目前健康值:"+role.getCurrentHp());
                if (role.getCurrentHp() <= 0) {
                    System.out.println("老衲这一生....值了！");
                    return;
                }
                break;
            }
        } while (true);
    }
    //神使类游戏副本
    public void playProtoss(Role role,Monsters monster){
        System.out.println("黑暗中出现一个怪物:\t\t血量"+monster.getHp()+".攻击力"+monster.getAtt()+".防御力"+monster.getDef());
        do {
            Random random=new Random();
            int opps=random.nextInt(4);
            System.out.println("*************************");
            System.out.print("1、普通攻击 2、特殊技能1号 3、特殊技能2号 4、特殊技能3号 5、逃跑：");
            int choice=input.nextInt();
            countDown();
            switch (choice){
                case 1:
                    new ProtossRace().att(role,monster);
                    if(monster.getHp()<=0){
                        System.out.println("干的漂亮！");
                        System.out.println("怪物的口袋中闪闪发光.....");
                        outComes(role,monster);
                        return;
                    }
                    break;
                case 2:
                    try {
                        new ProtossRace().att1(role,monster);
                        if(monster.getHp()<=0){
                            System.out.println("干的漂亮！");
                            System.out.println("怪物的口袋中闪闪发光.....");
                            outComes(role,monster);
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    try {
                        new ProtossRace().att2(role,monster);
                        if(monster.getHp()<=0){
                            System.out.println("干的漂亮！");
                            System.out.println("怪物的口袋中闪闪发光.....");
                            outComes(role,monster);
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 4:
                    try {
                        new ProtossRace().att3(role,monster);
                        if(monster.getHp()<=0){
                            System.out.println("干的漂亮！");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 5:
                    System.out.println("打得好，我认输！");
                    return;
                default:
                    System.out.println("你说啥？我没带眼镜听不见!");
                    break;
            }
            for (int i = 0; i < sceneList.size(); i++) {                            //随机生成怪物回馈场景
                System.out.println("*************************");
                System.out.println("肉山大魔王嘴里嘀咕着什么...");
                System.out.println(sceneList.get(opps).getType()+"!随着技能来袭:"+sceneList.get(opps).getDescribe());
                role.setCurrentHp((role.getCurrentHp() - (monster.getAtt() * 1 - role.getDef())));
                countDown();
                if(role.getCurrentHp()<0){
                    role.setCurrentHp(0);
                }
                System.out.println("\t\t\t\t\t\t\t\t\t\t"+role.getName()+"血量下降:"+((monster.getAtt() * 1 - role.getDef()))+"点，目前健康值:"+role.getCurrentHp());
                if (role.getCurrentHp() <= 0) {
                    System.out.println("老衲这一生....值了！");
                    return;
                }
                break;
            }
        } while (true);
    }
    //掉落功能
    public void outComes(Role role,Monsters monster){
        Random random=new Random();
        int oppsGoods=random.nextInt(3);
        switch (oppsGoods+1){
            case 1:
                if(monster.getAtt()==5){
                    int oppsGold=random.nextInt(100);
                    System.out.println("摸索出物品1：增加攻击力+2");
                    role.setAtt(role.getAtt()+2);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                }
                else if(monster.getAtt()==15){
                    int oppsGold=random.nextInt(500);
                    System.out.println("摸索出物品1：增加攻击力+3");
                    role.setAtt(role.getAtt()+3);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                }
                else if(monster.getAtt()==40){
                    int oppsGold=random.nextInt(1000);
                    System.out.println("摸索出物品1：增加攻击力+7 && 增加防御力+3");
                    role.setAtt(role.getAtt()+7);
                    role.setDef(role.getDef()+3);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                }
                userSerialize();
                break;
            case 2:
                if(monster.getAtt()==5){
                    int oppsGold=random.nextInt(100);
                    System.out.println("摸索出物品2：增加防御力+1");
                    role.setDef(role.getDef()+1);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                }
                else if(monster.getAtt()==15){
                    int oppsGold=random.nextInt(500);
                    System.out.println("摸索出物品2：增加防御力+2");
                    role.setDef(role.getDef()+2);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                }
                else if(monster.getAtt()==40){
                    int oppsGold=random.nextInt(1000);
                    System.out.println("摸索出物品2：增加血量+100 && 增加防御力+4");
                    role.setHp(role.getHp()+100);
                    role.setDef(role.getDef()+4);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                }
                userSerialize();
                break;
            case 3:
                if(monster.getAtt()==5){
                    int oppsGold=random.nextInt(100);
                    System.out.println("摸索出物品3：增加血量+20");
                    role.setHp(role.getHp()+20);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                    userSerialize();
                }
                else if(monster.getAtt()==15){
                    int oppsGold=random.nextInt(500);
                    System.out.println("摸索出物品3：增加血量+60");
                    role.setHp(role.getHp()+60);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                    userSerialize();
                }
                else if(monster.getAtt()==40){
                    int oppsGold=random.nextInt(1000);
                    System.out.println("摸索出物品3：增加攻击力+5 && 增加血量+150");
                    role.setAtt(role.getAtt()+5);
                    role.setHp(role.getHp()+150);
                    System.out.println("再摸索还摸到了:"+oppsGold+"枚金币");
                    role.setGold(role.getGold()+oppsGold);
                    userSerialize();
                }
                break;
        }
    }
    //倒计时功能
    public void countDown(){
        long endTime=System.currentTimeMillis()+1+5+1000;
        Date now=new Date();
        long currentTime=now.getTime();
        long seconds=(endTime-currentTime)/1000;
        while (true){
            seconds--;
            if(seconds<0) {
                break;
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    //游戏充值
    public void chong(Role role){
        System.out.println("请输入充值金额：");
        int gold=input.nextInt();
        unUserSerialize();
        role.setGold(role.getGold()+gold);
        userSerialize();
        System.out.println("土豪，已充值到账，求抱大腿！");
        System.out.println("这样,"+role.getName()+"的荷包里就有沉甸甸的："+role.getGold()+"金币啦！");
    }
    //猜大小得金币(随机)
    public void jinbi(Role role){
        unUserSerialize();
        System.out.println("赢一局，奖金翻倍，搏一搏，单车变摩托");
        System.out.println("请输入你的押金(不大于100金币)：");
        int cold=input.nextInt();
        role.setGold(role.getGold()-cold);
        if (cold>0&&cold<=100) {
            Random random = new Random();
            int num = random.nextInt(7);
            System.out.println("1、小（123小） 2、（456大） 3、(压0中宝翻两番)");
            int choice=input.nextInt();
            switch (choice){
                case 1:
                    if (num>0&&num<4){
                        role.setGold(role.getGold()+cold*2);
                        userSerialize();
                        System.out.println("运气真好！");
                        System.out.println(role.getName()+"抖一抖荷包，里面一共摸出来："+role.getGold()+"金币！");
                    }else {
                        System.out.println("小输怡情");
                        System.out.println(role.getName()+"抖一抖荷包，里面一共摸出来："+role.getGold()+"金币！");
                    }
                    break;
                case 2:
                    if (num>3&&num<7){
                        role.setGold(role.getGold()+cold*2);
                        userSerialize();
                        System.out.println("真是李时珍的秀！");
                        System.out.println(role.getName()+"抖一抖荷包，里面一共摸出来："+role.getGold()+"金币！");
                    }else {
                        System.out.println("钱来的匆匆去的也匆匆.");
                        System.out.println(role.getName()+"抖一抖荷包，里面一共摸出来："+role.getGold()+"金币！");
                    }
                    break;
                case 3:
                    if (num==0){
                        role.setGold(role.getGold()+cold*3);
                        userSerialize();
                        System.out.println("同样是九年义务教育，汝何秀？");
                        System.out.println(role.getName()+"抖一抖荷包，里面一共摸出来："+role.getGold()+"金币！");
                    }else {
                        System.out.println("再来一次就中了！");
                        System.out.println(role.getName()+"抖一抖荷包，里面一共摸出来："+role.getGold()+"金币！");
                    }
                    break;
                default:
                    System.out.println("给你个教训，钱别乱放！");
                    System.out.println(role.getName()+"抖一抖荷包，里面一共摸出来："+role.getGold()+"金币！");
                    break;
            }
        }else {
            System.out.println("押金不能超过一百！");
        }
        userSerialize();
    }
    //查看人物状态
    public void shuxing(Role role) {
        System.out.println("****人物属性****");
        System.out.println();
        System.out.println("昵称\t攻击力\t防御力\t血量\t当前血量\t魔力值\t当前魔力值\t金币");
        unUserSerialize();
        System.out.println(role.getName()+"\t"+role.getAtt()+"\t\t"+role.getDef()+"\t\t"+
                role.getHp()+"\t\t\t"+role.getCurrentHp()+"\t\t\t"+role.getMp()+"\t\t"+role.getCurrentMp()
                +"\t\t"+role.getGold());
        System.out.println();
    }
    //人物属性
    public void renwu(Role role){
        System.out.println("1、查看人物当前状态：");
        System.out.println("2、更改昵称");
        System.out.println("3、返回是一页");
        int xuanZe=input.nextInt();
        switch (xuanZe){
            case 1:
                shuxing(role);
                break;
            case 2:
                niCheng(role);
                break;
            case 3:
                return;

        }
    }
    //修改昵称
    public void niCheng(Role role){
        unUserSerialize();
        System.out.println("请输入您想修改的名称：");
        String name=input.next();
        role.setName(name);
        userSerialize();

    }
    //游戏商场
    public void shop(Role role) {
        System.out.println("请选择如下商品：");
        System.out.println("1、补血丹  150金币：增加当前HP+20以及HP上限+20");
        System.out.println("2、补气丸  150金币：增加当前MP+20以及MP上限+20");
        System.out.println("3、大力丸  150金币：攻击力+3");
        System.out.println("4、钢筋铁骨片  150金币：防御力+3");
        System.out.println("5、六味地黄丸  300金币：瞬间满HP+满MP");
        System.out.println("6、返回上一页面");
        int xuanSc = input.nextInt();
        switch (xuanSc) {
            case 1:
                buXue(role);
                break;
            case 2:
                buqi(role);
                break;
            case 3:
                dali(role);
                break;
            case 4:
                gangjin(role);
                break;
            case 5:
                liuwei(role);
                break;
            case 6:
                return;
        }
    }
    //补血丹
    public void buXue(Role role) {
        unUserSerialize();
        if (role.getGold() >= 150) {
            role.setHp(role.getHp() + 20);
            role.setCurrentHp(role.getCurrentHp() + 20);
            role.setGold(role.getGold() - 150);
            System.out.println("HP+20!");
            System.out.println("现在"+role.getName()+"有健康值："+role.getCurrentHp()+",血槽上限："+role.getHp()+"!");
        } else {
            System.out.println("你个穷鬼，买不起！充钱吧");
        }
        userSerialize();
    }
    //补气丸
    public void buqi(Role role) {
        unUserSerialize();
        if (role.getGold() >= 150) {
            role.setMp(role.getMp() + 20);
            role.setCurrentMp(role.getCurrentMp() + 20);
            role.setGold(role.getGold() - 150);
            System.out.println("魔力+20!");
            System.out.println("现在"+role.getName()+"有魔法值："+role.getCurrentMp()+",总魔法量："+role.getMp()+"!");
        } else {
            System.out.println("你太穷了，根本买不起！充钱你就会变强");
        }
        userSerialize();

    }
    //大力丸
    public void dali(Role role) {
        unUserSerialize();
        if (role.getGold() >= 150) {
            role.setAtt(role.getAtt() + 20);
            role.setGold(role.getGold() - 150);
            System.out.println("攻击力+20!");
            System.out.println("现在"+role.getName()+"有攻击力:"+role.getAtt()+"！又有劲提剑了！");
        } else {
            System.out.println("马化腾爸爸说过，充钱你就会变强");
        }
        userSerialize();
    }
    //钢筋铁骨片
    public void gangjin(Role role){
        unUserSerialize();
        if (role.getGold() >= 150) {
            role.setDef(role.getDef() + 20);
            role.setGold(role.getGold() - 150);
            System.out.println("def+20!");
            System.out.println("现在"+role.getName()+"有防御力:"+role.getDef()+"！又有劲提盾了！");
        } else {
            System.out.println("赶紧去搬两块砖充点钱吧");
        }
        userSerialize();

    }
    //六味地黄丸
    public  void liuwei(Role role){
        unUserSerialize();
        if (role.getGold() >= 300) {
            role.setCurrentHp(role.getHp());
            role.setCurrentMp(role.getMp());
            role.setGold(role.getGold() - 300);
            System.out.println("HP==MAX   信春哥得永生   MP==MAX");
            System.out.println(role.getName()+"的血槽满满"+role.getCurrentHp()+"的蓝槽也满满"+role.getCurrentMp());
        } else {
            System.out.println("充钱 充钱 充钱");
        }
        userSerialize();

    }
    //看广告得金币
    public void ad(Role role){
                System.out.println ();
                System.out.println ("Loading...正在广告时间~~~");
                advertiment (role);
                Thread thread = new Thread();
                thread.start();
                System.out.println ();
                System.out.println ("大吉大利，获得100金币");
                System.out.println ("");
                System.out.println ("向钱看！向钱看！啦啦~");
                System.out.println ("向钱看！向钱看！啦啦啦啦啦~");
                System.out.println ("");
                System.out.println ("                                  ");
                System.out.println ("               **  **             ");
                System.out.println ("              * **** *            ");
                System.out.println ("               * ** *             ");
                System.out.println ("            ---= ** =---         ");
                System.out.println ("               *******            ");
                System.out.println ("             *-*- $ --**          ");
                System.out.println ("           *-*-   $  --**         ");
                System.out.println ("          *-*-  $$$$$$ -**        ");
                System.out.println ("         *-*-  $$ $  $$ -**       ");
                System.out.println ("        *-*-  $$  $      -**      ");
                System.out.println ("       *-*-    $$$$$$$   --**     ");
                System.out.println ("      *-*--       $  $$   --**    ");
                System.out.println ("     *-*----  $$  $ $$    ---**   ");
                System.out.println ("    *-*------  $$$$$$  -------**  ");
                System.out.println ("    *-*---------  $  ----------** ");
                System.out.println ("    *-*---------  $  ----------** ");
                System.out.println ("     *-*  恭喜老板获得100大洋 --** ");
                System.out.println ("      ***--------------------***  ");
                System.out.println ("       ************************   ");
                System.out.println(role.getName()+"抖一抖荷包，里面一共摸出来："+role.getGold()+"金币！");
    }
    //看广告得金币
    public void advertiment(Role role){
        // 获取距离当前时间对应的毫秒数
        long endTime = System.currentTimeMillis() + 1 * 6 * 1000;
        // 获取系统当前时间
        Date now = new Date();
        // 获取当前时间点对应的毫秒数
        long currentTime = now.getTime();
        // 计算两个时间点相差的秒数
        long seconds = (endTime - currentTime) / 1000;

        while (true) {
            System.out.println("还剩下: " + seconds + " s");
            seconds--;
            if (seconds<0){
                break;
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        unUserSerialize();
        role.setGold(role.getGold()+100);
        userSerialize();
    }
}

