package yonas;

/**
 * Created by Hongsi on 23/08/2018.
 */
public class BeginnerMode {
}
