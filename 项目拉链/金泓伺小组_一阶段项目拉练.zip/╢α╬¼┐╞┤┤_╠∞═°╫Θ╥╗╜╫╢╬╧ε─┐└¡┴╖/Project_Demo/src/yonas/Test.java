package yonas;

import java.util.Random;

/**
 * Created by Hongsi on 23/08/2018.
 */
public class Test {
    public static void main(String[] args) {
        Random random=new Random();
        int opps=random.nextInt(4);
        int oppsGoods=random.nextInt(3);
        System.out.println(opps);
        System.out.println(oppsGoods);

    }
}
