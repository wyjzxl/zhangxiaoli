import javax.sql.rowset.spi.SyncResolver;
import java.io.Serializable;

/**
 * Created by 木鬼 on 2018/8/22.
 * 人族类
 */
public class HumanRace extends Race implements SkillOne,SkillTwo,Serializable {
    private String name;  //种族名称
    public HumanRace(String name) {
        super();
        this.name=name;
    }
    public HumanRace() {
        this.hp = 100;
        this.att = 10;
        this.def = 2;
        this.mp = 60;
        this.name="人族";
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    @Override
    public void info() {
        System.out.println("人族：");
        System.out.println("  血量值：" + this.hp + "  魔法值：" + this.mp + "  攻击力：" + this.att + "  防御力：" + this.def);
    }
    //普通攻击
    @Override
    public void att(Role role, Monsters monsters) {
        monsters.setHp((monsters.getHp() - (role.getAtt() - monsters.getDef())));
        if(monsters.getHp()<0){
            monsters.setHp(0);
        }
        System.out.println("断子绝孙脚！！！******怪兽生命值降低" + ((role.getAtt() - monsters.getDef())) + "点！"+"目前怪兽还有"+monsters.getHp()+"点血量");
    }
    @Override
    //技能一：大力出奇迹
    public void att1(Role role, Monsters monsters) throws Exception {
        if (role.getCurrentMp() >= 10) {
            role.setCurrentMp(role.getCurrentMp() - 10);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 1.2) - monsters.getDef())));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName() + "使用了大力出奇迹，对怪兽造成了" + (int) (role.getAtt() * 1.2 - monsters.getDef()) + "点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        } else {
            System.out.println("魔法值不够！魔法值不够！");
            System.out.println("本次将使用普通攻击！");
            att(role, monsters);
        }
    }
    @Override
    //技能二：洪荒之力
    public void att2(Role role, Monsters monsters) throws Exception {
        if (role.getCurrentMp() >= 20) {
            role.setCurrentMp(role.getCurrentMp() - 20);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 1.5) - monsters.getDef())));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName() + "使用了洪荒之力，系哩啪啦系哩啪啦的对怪兽造成了"
                    + (int) (role.getAtt() * 1.5 - monsters.getDef()) + "点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        }else if (role.getCurrentMp() >= 10) {
            role.setCurrentMp(role.getCurrentMp() - 10);
            monsters.setHp((int) (monsters.getHp() - ((role.getAtt() * 1.2) - monsters.getDef())));
            if(monsters.getHp()<0){
                monsters.setHp(0);
            }
            System.out.println(role.getName() + "使用了大力出奇迹，对怪兽造成了"
                    + (int) (role.getAtt() * 1.2 - monsters.getDef()) + "点伤害！"+"目前怪兽还有"+monsters.getHp()+"点血量");
        } else {
            System.out.println("魔法值不够！魔法值不够！");
            System.out.println("本次将使用断子绝孙脚攻击！");
            att(role, monsters);
        }
    }
}
