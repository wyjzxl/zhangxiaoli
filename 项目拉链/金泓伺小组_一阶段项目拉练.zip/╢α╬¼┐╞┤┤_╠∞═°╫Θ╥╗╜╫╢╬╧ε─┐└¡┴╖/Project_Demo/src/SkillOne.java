/**
 * Created by 木鬼 on 2018/8/22.
 * 技能一：大力出奇迹接口
 */
public interface SkillOne {
    public void att1(Role role,Monsters monsters)throws Exception;
}
