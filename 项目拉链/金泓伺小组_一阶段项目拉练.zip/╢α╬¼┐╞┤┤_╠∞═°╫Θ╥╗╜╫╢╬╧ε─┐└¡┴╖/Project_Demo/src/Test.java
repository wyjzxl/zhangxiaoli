/**
 * Created by 木鬼 on 2018/8/23.
 * 测试类
 */
public class Test {
    public static void main(String[] args) {
        Opera opera=new Opera();
        opera.menu1();
    }
}
