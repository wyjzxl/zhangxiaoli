/**
 * Created by 木鬼 on 2018/8/22.
 * 技能二：洪荒之力接口
 */
public interface SkillThree {
    public void att3(Role role,Monsters monsters)throws Exception;
}
