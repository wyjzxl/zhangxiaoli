import java.io.Serializable;

/**
 * Created by 83976 on 2018/8/22.
 * 角色类
 */
public class Role implements Serializable {
    private String id;         //账号
    private String name;      //昵称
    private Race race;        //种族
    private int att;          //攻击力
    private int def;          //防御力
    private int hp;           //血量值
    private int currentHp;  //当前血量值
    private int mp;          //魔力值
    private int currentMp;  //当前血量值
    private int gold;        //金币
    public Role() {
    }

    public Role(String id, String name, Race race, int att, int def, int hp, int currentHp, int mp, int currentMp, int gold) {
        this.id = id;
        this.name = name;
        this.race = race;
        this.att = att;
        this.def = def;
        this.hp = hp;
        this.currentHp = currentHp;
        this.mp = mp;
        this.currentMp = currentMp;
        this.gold = gold;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Race getRace() {
        return race;
    }
    public void setRace(Race race) {
        this.race = race;
    }
    public int getAtt() {
        return att;
    }
    public void setAtt(int att) {
        this.att = att;
    }
    public int getDef() {
        return def;
    }
    public void setDef(int def) {
        this.def = def;
    }
    public int getHp() {
        return hp;
    }
    public void setHp(int hp) {
        this.hp = hp;
    }
    public int getMp() {
        return mp;
    }
    public void setMp(int mp) {
        this.mp = mp;
    }
    public int getGold() {
        return gold;
    }
    public void setGold(int gold) {
        this.gold = gold;
    }
    public int getCurrentHp() {
        return currentHp;
    }
    public void setCurrentHp(int currentHp) {
        this.currentHp = currentHp;
    }
    public int getCurrentMp() {
        return currentMp;
    }
    public void setCurrentMp(int currentMp) {
        this.currentMp = currentMp;
    }
}
