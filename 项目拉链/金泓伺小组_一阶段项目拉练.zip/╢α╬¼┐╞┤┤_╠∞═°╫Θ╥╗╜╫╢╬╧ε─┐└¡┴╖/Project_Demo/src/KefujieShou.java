import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 * Created by Administrator on 2018/8/23.
 * 游戏客服端口
 */
public class KefujieShou {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);

            try {
                do {
                    ServerSocket serverSocket = new ServerSocket(8800);
                    Socket socket = serverSocket.accept();
                    InputStream is = socket.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String info = null;
                    while ((info = br.readLine()) != null) {
                        System.out.println("玩家：" + info);
                    }
                    //给玩家回复
                    OutputStream os = socket.getOutputStream();
                    String reply ="已收到您的意见，请耐心等候！";
                    os.write(reply.getBytes());
                    br.close();
                    is.close();
                    socket.close();
                    serverSocket.close();
                } while (true);
            }catch (IOException e) {
                e.printStackTrace();
            }

                }
            }


