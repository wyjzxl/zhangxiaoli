import java.io.Serializable;

/**
 * Created by 木鬼 on 2018/8/22.
 * 怪兽类
 */
public class Monsters implements Serializable {
    private int hp;     //血量值
    private int mp;     //魔力值
    private int att;    //攻击力
    private int def;    //防御力
    public Monsters(int hp, int mp, int att, int def) {
        this.hp = hp;
        this.mp = mp;
        this.att = att;
        this.def = def;
    }
    public int getHp() {
        return hp;
    }
    public void setHp(int hp) {
        this.hp = hp;
    }
    public int getMp() {
        return mp;
    }
    public void setMp(int mp) {
        this.mp = mp;
    }
    public int getAtt() {
        return att;
    }
    public void setAtt(int att) {
        this.att = att;
    }
    public int getDef() {
        return def;
    }
    public void setDef(int def) {
        this.def = def;
    }
}
