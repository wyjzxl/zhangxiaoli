import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 木鬼 on 2018/8/22.
 * 初始化类
 */
public class Info implements Serializable {
    public static Map<String,User>userMap=new HashMap<>();                    //用户的集合
    public static List<Role>roleList=new ArrayList<>();                      //角色集合
    public static List<Scene>sceneList=new ArrayList<>();                    //怪兽的攻击场景
    static {
        //初始化一个用户的三个角色信息
        Role role1=new Role("123","赵章槐-宙斯",new HumanRace(),10,2,100,100,60,60,100);
        Role role2=new Role("123","方晔-大魔王",new DemonRace(),12,4,100,100,20,20,100);
        Role role3=new Role("123","金泓伺-圣骑士",new ProtossRace(),8,2,100,100,80,80,100);
        roleList.add(role1);
        roleList.add(role2);
        roleList.add(role3);
        //初始化一条用户信息
        User user1=new User("123","123456",roleList);
        userMap.put(user1.getId(),user1);
    }
    static {
        //初始化怪兽攻击场景
        Scene scene1=new Scene("排山倒海","只听一声排山倒海的猛啸，一个巴掌就呼了过来！");
        Scene scene2=new Scene("葵花点穴手","敌不动，我不动，想动也不让动！");
        Scene scene3=new Scene("呼叫草泥马","伴着“苍茫的天涯是我的爱 绵绵的青山脚下花正开”的歌声，草泥马奔腾而过！");
        Scene scene4=new Scene("太极八卦连环掌","连环巴掌啪啪啪啪啪啪啪啪个不停！");
        sceneList.add(scene1);
        sceneList.add(scene2);
        sceneList.add(scene3);
        sceneList.add(scene4);
    }
}
