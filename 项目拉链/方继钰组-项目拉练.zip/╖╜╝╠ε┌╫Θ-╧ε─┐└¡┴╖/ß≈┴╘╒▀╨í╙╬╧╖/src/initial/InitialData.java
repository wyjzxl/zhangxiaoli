package initial;

import entity.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by GuCun on 2018/8/23.
 * 初始化信息
 */
public class InitialData {
    public static List<Equipment> equipmentList=new ArrayList<>();//设备列表
    public static List<Monster> monstersList=new ArrayList<>();//怪物列表
    public static List<Role> roleList=new ArrayList<>();//角色列表
    public static Map<String, Player> playerMap=new HashMap<>();//玩家Map


    static {
        Equipment equipment01=new Equipment(10,"新手剑",100, Buyed.Nobuy);
        Equipment equipment02=new Equipment(20,"生铁剑",300,Buyed.Nobuy);
        Equipment equipment03=new Equipment(30,"武圣剑",500,Buyed.Nobuy);
        equipmentList.add(equipment01);
        equipmentList.add(equipment02);
        equipmentList.add(equipment03);
    }

    static {
        Role role01=new Role("咸鱼",1000,20,100,0,0,null);
        Role role02=new Role("魔人",0,30,120,0,0,null);
        Role role03=new Role("游方术士",0,25,200,0,0,null);
        Role role04=new Role("剑圣",0,100,250,0,0,null);
        Role role05=new Role("魔师",0,50,200,0,0,null);
        roleList.add(role01);
        roleList.add(role02);
        roleList.add(role03);
        roleList.add(role04);
        roleList.add(role05);
    }

    static {
        Monster monster01=new Monster("菜鸡",10,15,60,150);
        Monster monster02=new Monster("土狗",50,100,200,200);
        Monster monster03=new Monster("恶鬼",100,300,500,500);

        monstersList.add(monster01);
        monstersList.add(monster02);
        monstersList.add(monster03);
    }

    static {
        Player player=new Player("111","123456",roleList.get(0));
        playerMap.put(player.getName(),player);
    }
}
