package utils;

import biz.Hunter;
import entity.Monster;
import entity.Player;
import initial.InitialData;

import java.util.List;
import java.util.Map;


/**
 * Created by 89528 on 2018/8/23.
 * 升级类
 */
public class UpGrade {
    List<Monster> monstersLists= InitialData.monstersList;
    Map<String, Player> playerMaps= InitialData.playerMap;
    String tag= Hunter.tag;
    public void upLv(){
        //当经验值大于100时升为1级
        if (playerMaps.get(tag).getRole().getExp()>=100 && playerMaps.get(tag).getRole().getLevel()<1){
            playerMaps.get(tag).getRole().setExp(0);
            playerMaps.get(tag).getRole().setLevel(1);
            playerMaps.get(tag).getRole().setDamage(playerMaps.get(tag).getRole().getDamage()+20);
            playerMaps.get(tag).getRole().setLifeValue(playerMaps.get(tag).getRole().getLifeValue()+100);

            System.out.println("成功升到1级！");

            //当经验值大于500时升级为2级
        }else if (playerMaps.get(tag).getRole().getExp()>=500 && playerMaps.get(tag).getRole().getLevel()<2){
            playerMaps.get(tag).getRole().setExp(0);
            playerMaps.get(tag).getRole().setLevel(2);
            playerMaps.get(tag).getRole().setDamage(playerMaps.get(tag).getRole().getDamage()+40);
            playerMaps.get(tag).getRole().setLifeValue(playerMaps.get(tag).getRole().getLifeValue()+300);

            System.out.println("成功升到2级！");

            //当经验值大于2000时升级为3级
        }else if (playerMaps.get(tag).getRole().getExp()>=2000 && playerMaps.get(tag).getRole().getLevel()<3){
            playerMaps.get(tag).getRole().setExp(0);
            playerMaps.get(tag).getRole().setLevel(3);
            playerMaps.get(tag).getRole().setDamage(playerMaps.get(tag).getRole().getDamage()+100);
            playerMaps.get(tag).getRole().setLifeValue(playerMaps.get(tag).getRole().getLifeValue()+900);

            System.out.println("成功升到3级！");

        }
    }
}
