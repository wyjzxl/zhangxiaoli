package utils;

import biz.Hunter;
import entity.Buyed;
import entity.Equipment;
import entity.Player;
import initial.InitialData;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by GuCun on 2018/8/23.
 * 背包类
 */
public class Package {
    Scanner input=new Scanner(System.in);
    String tag= Hunter.tag;
    List<Equipment> equipmentList= InitialData.equipmentList;
    Map<String, Player> playerMaps= InitialData.playerMap;
    //查看背包
    public void checkPackage(){
        do {
            System.out.println("===============狩猎者背包=============");
            System.out.println("1.查看已经拥有的装备     2.选择佩戴的装备     0.退出背包系统");
            System.out.println("请输入您的选择");
            int packChoice=input.nextInt();
            switch (packChoice){
                case 0:
                    //退出背包系统
                    return;
                case 1:
                    //查看装备
                    showEquipmentBuyed();
                    break;
                case 2:
                    //选择佩戴的装备
                    wearEquipment();
                    break;
            }
        }while (true);
    }

    //查看已拥有装备
    public void showEquipmentBuyed(){
        System.out.println("装备名称"+"\t\t"+"攻击力");
        for (int i = 0; i <equipmentList.size() ; i++) {
            if (equipmentList.get(i).getIsBuy().equals(Buyed.Buyed)){
                System.out.println(equipmentList.get(i).getName()+"\t\t\t"+equipmentList.get(i).getDamage());
            }
        }
    }


    //选择佩戴装备
    public void wearEquipment(){
        System.out.println("序号"+"\t"+"装备名称"+"\t\t"+"攻击力");
        for (int i = 0; i <equipmentList.size() ; i++) {
            if (equipmentList.get(i).getIsBuy().equals(Buyed.Buyed)){
                System.out.println((i+1)+"、\t\t"+equipmentList.get(i).getName()+"\t\t\t"+equipmentList.get(i).getDamage());
            }
        }
        System.out.println("是否需要穿戴装备（y/n）");
        String choose=input.next();
        if (choose.equals("y")){
            System.out.println("请输入您想要穿戴的装备：");
            int whichGet=input.nextInt();
            if (equipmentList.get(whichGet-1).getIsBuy().equals(Buyed.Buyed)) {
                playerMaps.get(tag).getRole().setEquipment(equipmentList.get(whichGet - 1));//修改当前穿戴的装备
                playerMaps.get(tag).getRole().setDamage(playerMaps.get(tag).getRole().getDamage()
                        + equipmentList.get(whichGet - 1).getDamage());//修改当前角色的攻击力
                System.out.println("装备成功！");
            }
            if(equipmentList.get(whichGet-1).getIsBuy().equals(Buyed.Nobuy)){
                System.out.println("您并没有这把武器！");
            }
            if (playerMaps.get(tag).getRole().getEquipment().getName().equals(equipmentList.get(whichGet-1))){
                System.out.println("该装备已经拥有");
            }
        }else {
            return;
        }
    }
}
