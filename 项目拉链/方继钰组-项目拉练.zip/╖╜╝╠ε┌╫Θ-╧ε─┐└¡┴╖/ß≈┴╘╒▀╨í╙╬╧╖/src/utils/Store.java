package utils;

import biz.Hunter;
import entity.Buyed;
import entity.Equipment;
import entity.Player;
import entity.Role;
import initial.InitialData;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by GuCun on 2018/8/23.
 * 操作方法
 */
public class Store {
    List<Equipment> equipmentList= InitialData.equipmentList;
    List<Role> roleList=InitialData.roleList;
    Map<String, Player> playerMap=InitialData.playerMap;
    Scanner input=new Scanner(System.in);

    String tag= Hunter.tag;

    //购买装备
    public void Equipment() {
        System.out.println("当前金币："+playerMap.get(tag).getRole().getGold());
        System.out.println("编号\t\t装备\t\t攻击力\t\t价格");
        for (int i = 0; i <equipmentList.size(); i++) {

            System.out.println((i+1)+"\t\t\t"+equipmentList.get(i).getName()+
                    "\t\t"+equipmentList.get(i).getDamage()+"\t\t\t"+equipmentList.get(i).getGold());

        }
        System.out.print("是否购买装备（y/n）：");
        String choose = input.next();
        if (choose.equals("y")) {
            buyEquipment();
        }else {
            return;
        }
    }
    public void buyEquipment(){
        System.out.print("请选择您要购买的装备：");
        int choice=input.nextInt();
        if (playerMap.get(tag).getRole().getGold()>=equipmentList.get(choice-1).getGold()) {
            playerMap.get(tag).getRole().setGold(playerMap.get(tag).getRole().getGold()-equipmentList.get(choice-1).getGold());
            equipmentList.get(choice-1).setIsBuy(Buyed.Buyed);
            System.out.println("剩余金币："+playerMap.get(tag).getRole().getGold());

        } else {
            System.out.println("您的金币不足！");
            return;
        }
        switch (choice) {
            case 1:
                System.out.println("新手剑购买成功！");
                break;
            case 2:
                System.out.println("生铁剑购买成功！");
                break;
            case 3:
                System.out.println("武圣剑购买成功！");
                break;

        }
    }

}

