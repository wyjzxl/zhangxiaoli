package utils;

import biz.Hunter;
import service.Attack;
import entity.Monster;
import entity.Player;
import initial.InitialData;

import java.util.List;
import java.util.Map;

/**
 * Created by 89528 on 2018/8/23.
 * 攻击方式类
 *
 */
public class AttackMethod implements Attack{
    List<Monster> monstersLists= InitialData.monstersList;
    Map<String, Player> playerMaps= InitialData.playerMap;
    String tag= Hunter.tag; //传递用户名
    //玩家攻击怪物
    public int roleToMon(int rand) {
        int num=atk(monstersLists.get(rand).getLifeValue(),playerMaps.get(tag).getRole().getDamage());
        if (num>0){
            return num;
        }
        return 0;
    }
    //怪物攻击玩家
    public int monToRole(int rand) {
        int num = atk(playerMaps.get(tag).getRole().getLifeValue(), monstersLists.get(rand).getDamage());
        if (num>0){
            return num;
        }
        return 0;
    }

    @Override
    public int atk(int lifeValue, int attack) {
        return lifeValue-attack;
    }
}
