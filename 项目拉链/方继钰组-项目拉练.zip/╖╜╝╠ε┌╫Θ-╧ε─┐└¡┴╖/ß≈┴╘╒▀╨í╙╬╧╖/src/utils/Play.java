package utils;

import biz.Hunter;
import entity.Monster;
import entity.Player;
import initial.InitialData;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

/**
 * Created by  on 2018/8/23.
 * 战斗类
 * 循环遇敌
 */
public class Play {
    List<Monster> monstersLists= InitialData.monstersList;
    Map<String, Player> playerMaps= InitialData.playerMap;
    Scanner input=new Scanner(System.in);
    String tag=Hunter.tag;
    //随机遇敌
    public void encounter(){
        Random random=new Random();
        do {
            int rand=random.nextInt(3);
            System.out.println("前方出现了:"+monstersLists.get(rand).getName()+"\n"+"生命值："+monstersLists.get(rand).getLifeValue()
                    +"\t攻击力"+monstersLists.get(rand).getDamage());
            System.out.println("1、攻击\t2、逃跑\t3、结束战斗");
            int choice=input.nextInt();
            switch (choice){
                case 1:
                    new Fight().startFight(rand);
                    break;
                case 2:
                    System.out.println("打不过，先跑了！！！");
                    System.out.println("================================");
                    break;
                case 3:
                    new Hunter().secondMenue();
                    return;
            }
        }while (true);
    }
}
