package utils;

import biz.Hunter;
import entity.Monster;
import entity.Player;
import entity.Role;
import initial.InitialData;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by GuCun on 2018/8/23.
 */
public class ShowPlayerInfo {
    List<Monster> monstersLists= InitialData.monstersList;
    Map<String, Player> playerMaps= InitialData.playerMap;
    List<Role> roleLists=InitialData.roleList;
    Scanner input=new Scanner(System.in);
    String tag= Hunter.tag;
    public void showInfo(){
        //序列化
        new Hunter().reSerilizable();
        System.out.println("昵称\t\t等级 \t\t金币\t\t经验\t\t生命值\t\t攻击力");
        if (playerMaps!=null) {
            System.out.println(playerMaps.get(tag).getRole().getName() + "\t\t" + playerMaps.get(tag).getRole().getLevel() + "\t"
                    + "\t\t" + playerMaps.get(tag).getRole().getGold()
                    + "\t\t\t" + playerMaps.get(tag).getRole().getExp()
                    + "\t\t\t" + playerMaps.get(tag).getRole().getLifeValue()
                    + "\t\t\t" + playerMaps.get(tag).getRole().getDamage());
            System.out.println("-----------------------------------------------------------");
        }
        System.out.print("是否更换角色（y/n）：");
        String choose=input.next();
        if (choose.equals("y")) {
            showRole();
            System.out.print("请选择：");
            int choice = input.nextInt();
            switch (choice) {
                case 1:
                    if ( playerMaps.get(tag).getRole().getDamage()!=20) {
                        playerMaps.get(tag).setRole(roleLists.get(choice - 1));
                        System.out.println("更换成功！");
                        new Hunter().seliazible();
                    }else {
                        System.out.println("您正在使用此角色");
                    }
                    break;
                case 2:
                    if ( playerMaps.get(tag).getRole().getDamage()!=30) {
                        playerMaps.get(tag).setRole(roleLists.get(choice - 1));
                        System.out.println("更换成功！");
                        new Hunter().seliazible();
                    }else {
                        System.out.println("您正在使用此角色");
                    }
                    break;
                case 3:
                    if ( playerMaps.get(tag).getRole().getDamage()!=25) {
                        playerMaps.get(tag).setRole(roleLists.get(choice - 1));
                        System.out.println("更换成功！");
                        new Hunter().seliazible();
                    }else {
                        System.out.println("您正在使用此角色");
                    }
                    break;
                case 4:
                    if ( playerMaps.get(tag).getRole().getDamage()!=100) {
                        playerMaps.get(tag).setRole(roleLists.get(choice - 1));
                        System.out.println("更换成功！");
                        new Hunter().seliazible();
                    }else {
                        System.out.println("您正在使用此角色");
                    }
                    break;
                case 5:
                    if ( playerMaps.get(tag).getRole().getDamage()!=50) {
                        playerMaps.get(tag).setRole(roleLists.get(choice - 1));
                        System.out.println("更换成功！");
                        new Hunter().seliazible();
                    }else {
                        System.out.println("您正在使用此角色");
                    }
                    break;
            }
        }else {
            return;
        }
    }
    public void showRole(){
        System.out.println("昵称\t\t\t生命值\t\t\t攻击力");
        if (roleLists!=null) {
            for (int i = 0; i <roleLists.size() ; i++) {
                System.out.println((i + 1) + "、" + roleLists.get(i).getName()
                        + "\t\t\t\t" + roleLists.get(i).getLifeValue()
                        + "\t\t\t\t" + roleLists.get(i).getDamage());
            }
        }
    }
}
