package utils;

import biz.Hunter;
import entity.Monster;
import entity.Player;
import initial.InitialData;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by 89528 on 2018/8/23.
 * 战斗方式类
 * 回合制，每次战斗完成，玩家，怪物生命值都回复
 */
public class Fight {
    List<Monster> monstersLists= InitialData.monstersList;
    Map<String, Player> playerMaps= InitialData.playerMap;
    Scanner input=new Scanner(System.in);
    AttackMethod atm=new AttackMethod();//攻击方法
    String tag= Hunter.tag;
    public void startFight(int rand) {
        int user = playerMaps.get(tag).getRole().getLifeValue(); //战斗结束，人物生命值回复
        int monster = monstersLists.get(rand).getLifeValue();  //战斗结束，怪物生命值回复
        do {
            int num = atm.roleToMon(rand);
            monstersLists.get(rand).setLifeValue(num);
            System.out.println("怪物剩余生命;" + num);
            if (num > 0) {
                int number = atm.monToRole(rand);
                playerMaps.get(tag).getRole().setLifeValue(number);
                System.out.println(playerMaps.get(tag).getRole().getName() + "剩余生命:" + number);
                if (number > 0) {
                    System.out.println("1、攻击\t2、逃跑");
                    int choice = input.nextInt();
                    switch (choice) {
                        case 1:
                            continue;
                        case 2:
                            new Play().encounter();
                            break;
                    }

                } else {
                    playerMaps.get(tag).getRole().setLifeValue(user);
                    monstersLists.get(rand).setLifeValue(monster);
                    System.out.println("战斗失败！");
                    System.out.println("================================");
                    new Play().encounter(); //返回战斗类
                }
            } else {
                playerMaps.get(tag).getRole().setLifeValue(user);
                playerMaps.get(tag).getRole().setGold(playerMaps.get(tag).getRole().getGold() + monstersLists.get(rand).getGold());
                playerMaps.get(tag).getRole().setExp(playerMaps.get(tag).getRole().getExp() + monstersLists.get(rand).getExp());
                monstersLists.get(rand).setLifeValue(monster);
                new UpGrade().upLv();
                System.out.println("战斗胜利！");
                System.out.println("================================");
                new Hunter().reSerilizable();
                new Play().encounter();//返回战斗类
            }
        } while (true);
    }
}
