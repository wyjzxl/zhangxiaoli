package service;

/**
 * Created by 89528 on 2018/8/23.
 */
public interface Attack {
    public int atk(int lifeValue, int attack);
}
