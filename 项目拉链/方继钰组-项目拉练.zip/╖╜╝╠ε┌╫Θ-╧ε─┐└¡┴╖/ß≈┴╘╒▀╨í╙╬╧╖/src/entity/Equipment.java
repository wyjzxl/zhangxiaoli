package entity;

import java.io.Serializable;

/**
 * Created by GuCun on 2018/8/22.
 * 装备类
 */
public class Equipment implements Serializable{
    private int damage;//装备攻击力
    private String name;//装备名称
    private int gold;//装备金币
    private Buyed isBuy;//是否已经拥有


    public Equipment() {
    }

    public Equipment(int damage, String name, int gold, Buyed isBuy) {
        this.damage = damage;
        this.name = name;
        this.gold = gold;
        this.isBuy = isBuy;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public Buyed getIsBuy() {
        return isBuy;
    }

    public void setIsBuy(Buyed isBuy) {
        this.isBuy = isBuy;
    }
}
