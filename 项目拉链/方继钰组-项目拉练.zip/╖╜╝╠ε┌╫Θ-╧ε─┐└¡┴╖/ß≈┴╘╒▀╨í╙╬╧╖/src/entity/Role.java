package entity;

import java.io.Serializable;

/**
 * Created by GuCun on 2018/8/23.
 * 角色类
 */
public class Role extends BaseClass implements Serializable{
    private int level;//角色等级
    private Equipment equipment;//装备

    public Role() {
    }

    public Role(String name, int gold, int damage, int lifeValue, int exp, int level, Equipment equipment) {
        super(name, gold, damage, lifeValue, exp);
        this.level = level;
        this.equipment = equipment;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public Equipment getEquipment() {
        return equipment;
    }

    public void setEquipment(Equipment equipment) {
        this.equipment = equipment;
    }
}
