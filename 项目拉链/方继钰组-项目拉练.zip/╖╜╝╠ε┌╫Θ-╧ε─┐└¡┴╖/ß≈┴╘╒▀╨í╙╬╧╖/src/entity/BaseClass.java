package entity;

/**
 * Created by GuCun on 2018/8/23.
 * 角色和怪物的父类
 * 抽取它们的公共属性和方法
 */
public class BaseClass {
    private String name;  //名称
    private int gold;//金币
    private int damage;//攻击力
    private int lifeValue;//生命值
    private int exp;//经验值

    public BaseClass(){}

    public BaseClass(String name, int gold, int damage, int lifeValue, int exp) {
        this.name = name;
        this.gold = gold;
        this.damage = damage;
        this.lifeValue = lifeValue;
        this.exp = exp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getLifeValue() {
        return lifeValue;
    }

    public void setLifeValue(int lifeValue) {
        this.lifeValue = lifeValue;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }
}
