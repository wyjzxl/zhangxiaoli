package entity;

/**
 * Created by GuCun on 2018/8/23.
 * 枚举，显示装备是否已经购买
 */
public enum Buyed {
    Buyed,Nobuy;
}
