package entity;

/**
 * Created by GuCun on 2018/8/23.
 * 怪物类
 */
public class Monster extends BaseClass{

    public Monster() {
    }

    public Monster(String name, int gold, int damage, int lifeValue, int exp) {
        super(name, gold, damage, lifeValue, exp);
    }
}
