package entity;

import java.io.Serializable;

/**
 * Created by GuCun on 2018/8/22.
 * 玩家类
 */
public class Player implements Serializable{
    private String name;//玩家昵称
    private String password;//玩家密码
    private Role role;//玩家角色

    public Player() {
    }

    public Player(String name, String password, Role role) {
        this.name = name;
        this.password = password;
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
