package biz;

import entity.Player;
import entity.Role;
import initial.InitialData;
import utils.Package;
import utils.Play;
import utils.ShowPlayerInfo;
import utils.Store;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by GuCun on 2018/8/22.
 * 业务类
 * 进入狩猎者游戏菜单
 */
public class Hunter {
    File file=new File("玩家信息.txt");
    Scanner input=new Scanner(System.in);
    Map<String, Player> playerMap= InitialData.playerMap;
    List<Role> roleList=InitialData.roleList;
    public static String tag=null;

    //程序入口
    public static void main(String[] args) {
        Hunter begin=new Hunter();
        begin.seliazible();
        begin.mainMenu();
    }

    //主菜单
    public void mainMenu(){
        do {
            System.out.println("********狩猎者小游戏*************");
            System.out.println("1.注册     2.登录      3.退出");
            System.out.println("请输入您的选择：");
            int mainChioce=input.nextInt();
            switch (mainChioce){
                case 1:
                    //注册
                    register();
                    break;
                case 2:
                    //登录
                    loginIn();
                    break;
                case 3:
                    //退出
                    System.exit(1);
            }
        }while (true);

    }

    //二级菜单
    public void secondMenue(){
        do {
            System.out.println("***********欢迎您进入游戏***********");
            System.out.println("1.开始游戏");
            System.out.println("2.商城");
            System.out.println("3.个人信息");
            System.out.println("4.背包");
            System.out.println("5.退出游戏");
            System.out.println("请输入您的选择：");
            int seconedChioce=input.nextInt();
            switch (seconedChioce){
                case 1:
                    //开始游戏
                    Play play=new Play();
                    play.encounter();
                    break;
                case 2:
                    //商城
                    Store store=new Store();
                    //购买装备
                    store.Equipment();
                    break;
                case 3:
                    //查看个人信息
                    ShowPlayerInfo s=new ShowPlayerInfo();
                    s.showInfo();
                    break;
                case 4:
                    //查看背包
                    Package p=new Package();
                    p.checkPackage();
                    break;
                case 5:
                    //退出游戏
                    mainMenu();
                    return;
            }
        }while (true);
    }
    //玩家信息序列化
    public void seliazible(){
        ObjectOutputStream oos=null;
        try {
            oos=new ObjectOutputStream(new FileOutputStream(file));
            oos.writeObject(playerMap);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //玩家信息反序列化
    public void reSerilizable(){
        ObjectInputStream ois=null;
        try {
            ois=new ObjectInputStream(new FileInputStream(file));
            Map<String,Player> playerMap= (Map<String, Player>) ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            try {
                ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //玩家登录
    public void loginIn(){
        reSerilizable();
        boolean flag=false;//默认没有登录成功
        System.out.println("请输入您的用户名：");
        String name=input.next();
        System.out.println("请输入密码：");
        String password=input.next();
        for (String s:playerMap.keySet()){
            if (playerMap.get(s).getName().equals(name)&&playerMap.get(s).getPassword().equals(password)){
                flag=true;
            }
        }
        if (flag){
            System.out.println("登录成功!!!");
            tag=name;
            secondMenue();
        }else {
            System.out.println("登录失败，请检查用户名密码是否正确");
        }
    }

    //玩家注册
    public void register(){
        reSerilizable();
        System.out.println("请输入游戏昵称：");
        String name=input.next();
        System.out.println("请输入密码：（密码固定为6位）");
        String password=input.next();
        System.out.println("请确认您的密码：");
        String confirePassword=input.next();
        byte []bytes=password.getBytes();
        boolean flag=true;//默认游戏昵称没有被占用
        for (String s:playerMap.keySet()){
            if (playerMap.get(s).getName().equals(name)){
                flag=false;
                break;
            }
        }
        if (flag){
            if (password.equals(confirePassword)&&bytes.length==6){
                playerMap.put(name,new Player(name,password,roleList.get(0)));
                seliazible();
                System.out.println("恭喜您注册成功");
            }
            if (bytes.length!=6){
                System.out.println("您设置的密码不符合格式");
            }
            if (!(password.equals(confirePassword))){
                System.out.println("两次输入密码不一致！");
            }
        }else {
            System.out.println("用户名已经被占用");
        }
    }
}
