package demo01;

import KTV.Text;

import java.io.*;
import java.net.Socket;
import java.util.*;

/**
 * Created by Administrator on 2018/8/22.
 * 操作类
 */
public class Opera {
    File file = new File("菜品.txt");
    File file1=new File("user.txt");
    File file2=new File("房间.txt");
    Map<Integer,FangJian>fangjianMap= InitilizeInfoF.fangjianMap;
    Map<Integer, CaiPin> caiPinMap = InitilizeInfo.caiPinMap;
    Map<String, Users> map = InitInfo.map;//用户集合
    Map<String, Security> map1 = InitInfo.map1;//密保集合
    Scanner input = new Scanner(System.in);
    boolean flag;
    Text text= new Text();
//一级菜单
    public void firstMenu() {
        do {
            System.out.println("================一级菜单================");
            System.out.print("1、注册\t");
            System.out.print("2、登录\t");
            System.out.print("3、注销用户\t");
            System.out.print("4、联系客服\t");
            System.out.println("0、退出");
            System.out.println("========================================");
            System.out.println("请选择：");
            int choose = input.nextInt();
            switch (choose) {
                case 0:
                    return;
                case 1:
                    register();
                    break;
                case 2:
                    login();
                    if (!flag){
                    secondMenu();}
                    else {
                        System.out.println("请重新登录");
                    }
                    break;
                case 3:
                    cancellation();
                    break;
                case 4:
                    customerService();
                    break;
                default:
            }
        } while (true);
    }
//注册
    public void register() {//注册
        System.out.println("请输入姓名");
        String name = input.next();
        System.out.println("请输入身份证号");
        String nameID = input.next();
        System.out.println("请输入手机号");
        String phoneId = input.next();
        System.out.println("请输入充值金额");
        double moeny = input.nextDouble();
        //随机生成账号
        int num = 0;
        do {
            Random random = new Random();
            num = random.nextInt(10000000);
            System.out.println("您的账号是" + num);
            break;
        } while (num > 1000000);
        boolean flag = false;
        String pwd1;
        String pwd2;
        do {
            System.out.println("请输入密码");
            pwd1 = input.next();
            System.out.println("请再次输入密码");
            pwd2 = input.next();
            if (pwd1.length() > 6 && pwd1.equals(pwd2)) {
                System.out.println("密码设置成功");
                flag = false;
            } else {
                System.out.println("密码设置错误，请重新设置");
                flag = true;
            }
        } while (flag);
        Users users = new Users(name, nameID, phoneId, "num", pwd1, moeny);
        map.put(nameID, users);
        System.out.println("请设置密保");
        System.out.println("请输入第一个问题?");
        String s1 = input.next();
        System.out.println("请输入答案:");
        String a1 = input.next();
        System.out.println("请输入第二个问题?");
        String s2 = input.next();
        System.out.println("请输入答案:");
        String a2 = input.next();
        System.out.println("请输入第三个问题？");
        String s3 = input.next();
        System.out.println("请输入答案：");
        String a3 = input.next();
        Security security = new Security(nameID, s1, a1, s2, a2, s3, a3);
        map1.put(nameID, security);
        System.out.println("注册完成");

    }
//登录
    public boolean login()  {
        boolean  flag=false;
        int c = 1;
        do {
            System.out.println("请输入身份证号：");
            String num = input.next();
            System.out.println("请输入密码：");
            String pwd = input.next();
            Set<String> s = map.keySet();
            for (String key : s) {
                if (map.get(key).getNameID().equals(num)
                        && map.get(key).getPwd().equals(pwd)) {
                    System.out.println("登录成功");
                    flag=false;
                    return flag;
                } else {
                    System.out.println("输入错误，请重新输入");
                    flag=true;
                    break;
                }
            }
            c++;
        } while (c<=3);
        System.out.println("输错三次，是否获取密码y/n");
        String str = input.next();
        if ("y".equalsIgnoreCase(str)) {
            System.out.println("回答密保问题，获取密码");
            System.out.println("请输入身份证：");
            String str1 = input.next();
            System.out.println("您的第一个问题：" + map1.get(str1).getFirstProble());
            System.out.println("您的答案是");
            String str2 = input.next();
            if (map1.get(str1).getFirstAnswer().equals(str2)) {
                System.out.println("回答正确");
                System.out.println("您的第二个问题：" + map1.get(str1).getSecondProble());
                System.out.println("您的答案是");
                String str3 = input.next();
                if (map1.get(str1).getSecondAnswer().equals(str3)) {
                    System.out.println("回答正确");
                    System.out.println("您的第三个问题：" + map1.get(str1).getThirdProble());
                    System.out.println("您的答案是");
                    String str4 = input.next();
                    if (map1.get(str1).getThirdAnswer().equals(str4)) {
                        System.out.println("密码获取成功");
                        System.out.println("您的密码是：" + map.get(str1).getPwd());
                        flag=true;
                    }
                } else {
                    System.out.println("联系客服");
                    flag=true;
                }
            }
        } else {
            System.out.println("联系客服");
            flag=true;
        }
        return flag;
    }
//注销
    public void cancellation() {//注销
        System.out.println("请输入要注销的身份证账号：");
        String num = input.next();
        //for (String key : map.keySet()) {
            if (map.containsKey(num)) {
                map.remove(num);
                System.out.println("注销成功");
            }
        }


//联系客服
    public void customerService() {//联系客服
        //1，快递点，端口
        Scanner input = new Scanner(System.in);
        try {
            while (true) {
                Socket socket = new Socket("localhost", 8888);
                //2、打开输出流
                OutputStream os = socket.getOutputStream();
                //3、输出

                System.out.print("我方输入内容：");
                String info = input.next();
                os.write(info.getBytes());
                socket.shutdownOutput();
                //接收服务端响应
                InputStream is = socket.getInputStream();
                BufferedReader bf = new BufferedReader(new InputStreamReader(is));
                String reply = null;
                while ((reply = bf.readLine()) != null) {
                    System.out.println("对方输入内容:" + reply);
                }
                //关闭socket
                os.close();
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //点餐
    public void secondMenu() {
        System.out.println("==================二级菜单=====================");
        System.out.println("1、点餐功能");
        System.out.println("2、就餐音乐");
        System.out.println("3、房间");
        System.out.println("4、个人信息");
        System.out.println("5、初始化系统");
        System.out.println("0、退出");
        System.out.println("================================================");
        System.out.println("请选择：");
        int choose = input.nextInt();
        switch (choose) {
            case 1:
              caidan();
                break;
            case 2:
               text.music();
                break;
            case 3:
              fanjiancaidan();
                break;
            case 4:
                ThreearyMune();
                break;
            case 5:
                break;
            case 0:
                return;

        }
    }


    //序列化
    public void serialize () {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(file));
            oos.writeObject(caiPinMap);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
    //反序列化

    public void unser(){
        ObjectInputStream ois=null;
        //如果文件不存在，创建文件（第一次运行程序时有效）
        if (file.exists()){
            try {
                ois=new ObjectInputStream(new FileInputStream(file));
               caiPinMap= (Map<Integer, CaiPin>) ois.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
    //序列化
    public void serializeF () {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(file2));
            oos.writeObject(fangjianMap);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
    //反序列化

    public void unserF(){
        ObjectInputStream ois=null;
        //如果文件不存在，创建文件（第一次运行程序时有效）
        if (file2.exists()){
            try {
                ois=new ObjectInputStream(new FileInputStream(file2));
                fangjianMap= (Map<Integer,FangJian>) ois.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
    public void serializeU () {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(file1));
            oos.writeObject(map);
            oos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
    public void unserU(){
        ObjectInputStream ois=null;
        //如果文件不存在，创建文件（第一次运行程序时有效）
        if (file1.exists()){
            try {
                ois=new ObjectInputStream(new FileInputStream(file1));
                map= (Map<String, Users>) ois.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
    //菜单
    public void caidan() {
        do {
            System.out.println("**********酒店招牌菜系**********");
            System.out.println("1，显示菜品信息");
            System.out.println("2，查询菜品：");
            System.out.println("3，添加菜品");
            System.out.println("4，修改菜品");
            System.out.println("5，删除菜品");
            System.out.println("6，退出");
            System.out.println("请选择");
            int shu = input.nextInt();
            switch (shu) {
                case 1:
                    xscp();
                    break;
                case 2:
                    cxcp();
                    break;
                case 3:
                    tjcp();
                    break;
                case 4:
                    xgcp();
                    break;
                case 5:
                    sccp();
                    break;
                case 6:
                    System.out.println("谢谢使用！");
                    return;
            }
        } while (true);
    }


        //显示菜品信息
        public void xscp() {
            unser();
            System.out.println("菜品编号\t菜系\t菜品名称\t菜品价格\t菜品类型");
            for (Integer key : caiPinMap.keySet()) {
                System.out.println(caiPinMap.get(key).getCaiBianHao() + "\t\t\t"+
                        caiPinMap.get(key).getCaiXiLie()+"\t"+
                        caiPinMap.get(key).getCaiName()+"\t"+
                        caiPinMap.get(key).getCaiJiaGe()+"\t\t\t"+
                        caiPinMap.get(key).getCaiLeixing());
            }
        }
        //查询菜品
        public void cxcp(){
            unser();
            System.out.println("请输入查询的菜品编号");
            int hao=input.nextInt();
            System.out.println("菜品编号\t菜系\t菜品名称\t菜品价格\t菜品类型");
                    for (int h:caiPinMap.keySet()){
                        if (caiPinMap.get(h).getCaiBianHao()==hao){
                    System.out.println(caiPinMap.get(h).getCaiBianHao() + "\t\t\t"+
                            caiPinMap.get(h).getCaiXiLie()+"\t"+
                            caiPinMap.get(h).getCaiName()+"\t"+
                            caiPinMap.get(h).getCaiJiaGe()+"\t\t\t                                                    "+
                            caiPinMap.get(h).getCaiLeixing());
                }
            }
        }
        //添加菜品
        public void tjcp(){
            unser();
            System.out.println("请输入新的菜品编号：");
            int hao=input.nextInt();
            System.out.println("请输入新的菜系：");
            String cx=input.next();
            System.out.println("请输入新的菜品名称：");
            String name=input.next();
            System.out.println("请输入新的菜品价格：");
            double jg=input.nextDouble();
            System.out.println("请输入新的菜品类型：");
            String lx=input.next();

            CaiPin caiPin=null;
            caiPin=new CaiPin(hao,cx,name,jg,lx);
            caiPinMap.put(caiPin.getCaiBianHao(),caiPin);
            serialize();
        }
    //修改菜品
        public void xgcp(){
            unser();
            System.out.println("请输入要修改的菜品编号：");
            Set<Integer>set=caiPinMap.keySet();
            int hao=input.nextInt();
            if (caiPinMap.containsKey(hao)){
                CaiPin caiPin=caiPinMap.get(hao);
                System.out.println("请重新输入菜品名称：");
                String name=input.next();
                caiPin.setCaiName(name);
                System.out.println("请重新输入菜系：");
                String cx=input.next();
                caiPin.setCaiXiLie(cx);
                System.out.println("请重新输入菜品价格：");
                double jg=input.nextDouble();
                caiPin.setCaiJiaGe(jg);
                System.out.println("请重新输入菜品类型：");
                String lx=input.next();
                caiPin.setCaiLeixing(lx);
                serialize();
            }else {
                System.out.println("Sorry,没有该菜品");
            }
        }
        //删除菜品
        public void sccp(){
            unser();
            System.out.println("请输入要删除的菜品编号：");
            int hao=input.nextInt();
            if (caiPinMap.containsKey(hao)){
                caiPinMap.remove(hao);
                System.out.println("删除菜品成功！");
                serialize();
            }else {
                System.out.println("Sorry,该菜品不存在！");
            }
        }
    public void ThreearyMune() {
        do {
            System.out.println("================二菜单================");
            System.out.print("1、查询个人信息\t");
            System.out.print("2、修改个人信息\t");
            System.out.print("3、修改个人密码\t");
            System.out.println("0、退出");
            System.out.println("========================================");
            System.out.println("请选择：");
            int choose = input.nextInt();
            switch (choose) {
                case 0:
                    //调用上级菜单
                    return;
                case 1:
                    viewInfomation();
                    break;
                case 2:
                    modifiInfomation();
                    break;
                case 3:
                    modifiPassWord();
                    break;
                default:
                    System.out.println("超出范围请重新输入");
            }
        } while (true);
    }
    //查询菜单的二级菜单
    public void viewInfomation() {
        do{ System.out.println("请选择查询模式");
            System.out.println("1、浏览");
            System.out.println("2、按照账户精确查询");
            System.out.println("3、按照姓名的一个字查询");
            System.out.println("4、返回上层菜单");
            System.out.println("5、退出");
            System.out.println("请选择：");
            int chose = input.nextInt();
            switch (chose) {
                case 1:
                    showInfo();
                    break;
                case 2:
                    showInfoTwo();
                    break;
                case 3:
                    showInfoThree();
                    break;
                case 4:
                   return;
                case 5:
                default:
            }
        } while (true);
    }
    //浏览
    public void showInfo() {
        unserU();
        System.out.println("用户姓名\t身份证号\t手机号码\t\t\t账号\t\t\t密码\t账户余额");
        for (String key : map.keySet()) {
            System.out.println(map.get(key).getName() +
                    map.get(key).getNameID() + "\t"+
                    map.get(key).getPhoneNo() +"\t"+
                    map.get(key).getAccountNo()+"\t"+
                    map.get(key).getPwd() +"\t"+
                    map.get(key).getMoney());
        }
    }
    //精确查找
    public void showInfoTwo(){
        unserU();
        System.out.println();
        System.out.println("请输入查找的账户Id");
        String nameId = input.next();
        for (String key : map.keySet()) {
            if(map.get(key).getNameID().equals(nameId)){
                System.out.println(map.get(key).getName() +
                        map.get(key).getNameID() + "\t"+
                        map.get(key).getPhoneNo() +"\t"+
                        map.get(key).getAccountNo()+"\t"+
                        map.get(key).getPwd() +"\t"+
                        map.get(key).getMoney());
            }
        }
    }
    //模糊查找
    public void showInfoThree(){
        unserU();
        System.out.println();
        System.out.println("请输入姓名的一个字");
        String nameFew = input.next();
        for (String key : map.keySet()) {
            if(map.get(key).getName().indexOf(nameFew)!=-1){
                System.out.println(map.get(key).getName() +
                        map.get(key).getNameID() + "\t"+
                        map.get(key).getPhoneNo() +"\t"+
                        map.get(key).getAccountNo()+"\t"+
                        map.get(key).getPwd() +"\t"+
                        map.get(key).getMoney());
            }
        }
    }

    //修改个人信息
    public void modifiInfomation() {
        unserU();
        boolean  flag=false;
        boolean f=false;
        //通过身份证号这一唯一的信息，反查集合
        do {
            System.out.println("请输入身份证号");//身份证号13位
            String nameId = input.next();
                if (map.containsKey(nameId) ) {
                    System.out.println("请输入的修改后的的11位手机电话号码");
                    String phoneNo=input.next();
                    map.get(nameId).setPhoneNo(phoneNo);
                    f=true;
                    flag=true;
                    break;
                }
            if (!f){
                System.out.println("输入有误，请重新输入");
                flag=false;
            }
    }while (flag);
    }
    //修改用户密码
    public void modifiPassWord(){
        unserU();
        //通过身份证号这一唯一的信息，反查集合
        boolean flag=false;
        do {
            System.out.println("请输入身份证号");//身份证号13位
            String nameId = input.next();
            int c = nameId.length();
            for (String key : map.keySet()) {
                if (map.get(key).getNameID().indexOf(nameId) != -1 && c == 13) {
                    System.out.println("请输入6位以上修改后的密码");
                    boolean flage = false;
                    do {
                        String pwd = input.next();
                        int e = pwd.length();
                        if ( e>= 6) {
                            map.get(nameId).setPwd(pwd);
                        } else {
                            System.out.println("输入有误，请重新输入");
                            flage = true;
                        }
                    } while (flage);
                }
            }
        } while (flag);
        serializeU();
        showInfo();
    }
    //菜单
    public void fanjiancaidan(){
        do {
            System.out.println("**********酒店特色房间**********");
            System.out.println("1，显示房间信息");
            System.out.println("2，查询房间：");
            System.out.println("3，入住房间");
            System.out.println("4，修改房间属性");
            System.out.println("5，退房");
            System.out.println("6，退出");
            System.out.println("请选择");
            int shu=input.nextInt();
            switch (shu){
                case 1:
                   xsfj();
                    break;
                case 2:
                    cxfj();
                    break;
                case 3:
                    tjfj();
                    break;
                case 4:
                    xgfj();
                    break;
                case 5:
                    tf();
                    break;
                case 6:
                    System.out.println("谢谢使用！");
                    return;
            }
        }while (true);
    }
    //显示房间信息

    public void xsfj(){
        unserF();
        System.out.println("房间编号\t房间风格\t房间名称\t房间价格\t房间类型");
        for (int key:fangjianMap.keySet()){
            System.out.println(fangjianMap.get(key).getFangBianHao()+"\t"+
                    fangjianMap.get(key).getFangFengG()+"\t"+
                    fangjianMap.get(key).getFangName()+"\t"+
                    fangjianMap.get(key).getFangJiaGe()+"\t"+
                    fangjianMap.get(key).getFangLeixing());
        }
        }

    //查询房间
    public void cxfj(){
        unserF();
        System.out.println("请输入查询的房间编号");
        int hao=input.nextInt();
        System.out.println("房间编号\t房间风格\t房间名称\t房间价格\t房间类型");
        if (fangjianMap.containsKey(hao)){
            System.out.println(fangjianMap.get(hao).getFangBianHao()+"\t"+
                    fangjianMap.get(hao).getFangFengG()+"\t"+
                    fangjianMap.get(hao).getFangName()+"\t"+
                    fangjianMap.get(hao).getFangJiaGe()+"\t"+
                    fangjianMap.get(hao).getFangLeixing());
        }
    }
    //入住房间
    public void tjfj(){
        unserF();
        System.out.println("请输入新的房间编号：");
        int hao=input.nextInt();
        System.out.println("请输入新的房间风格：");
        String fg=input.next();
        System.out.println("请输入新的房间名称：");
        String name=input.next();
        System.out.println("请输入新的房间价格：");
        double jg=input.nextDouble();
        System.out.println("请输入新的房间类型：");
        String lx=input.next();
        Set<Integer>set=fangjianMap.keySet();
        boolean flag=false;
        for (int key:set){
            if (hao==key){
                flag=true;
            }
        }
        if (!flag){
            FangJian fangjian=null;
            fangjian=new FangJian(hao,fg,name,jg,lx);
            fangjianMap.put(fangjian.getFangBianHao(),fangjian);
            serializeF();
        }
    }
    //修改房间属性
    public void xgfj(){
        unserF();
        System.out.println("请输入要修改的房间编号：");
        int hao=input.nextInt();
        Set<Integer>set=fangjianMap.keySet();
        if (fangjianMap.containsKey(hao)){
            FangJian fangjian=fangjianMap.get(hao);
            System.out.println("请重新输入房间名称：");
            String name=input.next();
            fangjian.setFangName(name);
            System.out.println("请重新输入房间风格：");
            String fg=input.next();
            fangjian.setFangFengG(fg);
            System.out.println("请重新输入房间价格：");
            double jg=input.nextDouble();
            fangjian.setFangJiaGe(jg);
            System.out.println("请重新输入房间类型：");
            String lx=input.next();
            fangjian.setFangLeixing(lx);
            serializeF();
        }else {
            System.out.println("Sorry,没有该房间");
        }
    }
    //退房
    public void tf(){
        unserF();
        System.out.println("请输入要退房编号：");
        int hao=input.nextInt();
        if (fangjianMap.containsKey(hao)){
            fangjianMap.remove(hao);
            System.out.println("退房成功：");
            serializeF();
        }else {
            System.out.println("Sorry,该房间不存在");
        }
    }
}




