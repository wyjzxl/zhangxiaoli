package demo01;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/8/22.
 * 密保
 */
public class Security implements Serializable{
    private String nameID;//身份证号
    private String firstProble;
    private String firstAnswer;
    private String secondProble;
    private String secondAnswer;
    private String ThirdProble;
    private String ThirdAnswer;

    public Security(String nameID,  String firstProble, String firstAnswer, String
            secondProble, String secondAnswer, String thirdProble, String thirdAnswer) {
        this.nameID = nameID;

        this.firstProble = firstProble;
        this.firstAnswer = firstAnswer;
        this.secondProble = secondProble;
        this.secondAnswer = secondAnswer;
        ThirdProble = thirdProble;
        ThirdAnswer = thirdAnswer;
    }
    public String getNameID() {
        return nameID;
    }
    public void setNameID(String nameID) {
        this.nameID = nameID;
    }
    public String getFirstProble() {
        return firstProble;
    }
    public void setFirstProble(String firstProble) {
        this.firstProble = firstProble;
    }
    public String getFirstAnswer() {
        return firstAnswer;
    }
    public void setFirstAnswer(String firstAnswer) {
        this.firstAnswer = firstAnswer;
    }
    public String getSecondProble() {
        return secondProble;
    }
    public void setSecondProble(String secondProble) {
        this.secondProble = secondProble;
    }
    public String getSecondAnswer() {
        return secondAnswer;
    }
    public void setSecondAnswer(String secondAnswer) {
        this.secondAnswer = secondAnswer;
    }
    public String getThirdProble() {
        return ThirdProble;
    }
    public void setThirdProble(String thirdProble) {
        ThirdProble = thirdProble;
    }
    public String getThirdAnswer() {
        return ThirdAnswer;
    }
    public void setThirdAnswer(String thirdAnswer) {
        ThirdAnswer = thirdAnswer;
    }
}
