package demo01;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2018/8/22.
 */
public class InitInfo {
    static Map<String,Users>map=new HashMap<>();
    static Map<String,Security>map1=new HashMap<>();
    static {
            Users user1=new Users("张三","0123456789123","13912345678","123456 ","1234567",10000.0);
            Users user2=new Users("张四","1123456789123","13912345678","123456 ","1234567",10000.0);
            Users user3=new Users("张五","2123456789123","13912345678","123456 ","1234567",10000.0);
            Users user4=new Users("张六","3123456789123","13912345678","123456 ","1234567",10000.0);
            map.put(user1.getNameID(),user1);
            map.put(user2.getNameID(),user2);
            map.put(user3.getNameID(),user3);
            map.put(user4.getNameID(),user4);
            Security security1=new Security("0123456789123","1","2","3","4","5","6");
            Security security2=new Security("1123456789123","1","2","3","4","5","6");
            Security security3=new Security("2123456789123","1","2","3","4","5","6");
            Security security4=new Security("3123456789123","1","2","3","4","5","6");
            map1.put(security1.getNameID(),security1);
            map1.put(security2.getNameID(),security2);
            map1.put(security3.getNameID(),security3);
            map1.put(security4.getNameID(),security4);
    }

}
