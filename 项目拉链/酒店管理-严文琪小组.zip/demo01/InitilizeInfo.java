package demo01;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
     * Created by 杨帆 on 2018/8/23.
     * 菜品初始化类
     *   private String caiBianHao;//菜品编号
     private String caiXiLie; //菜系
     private String caiName;//菜品名称
     private String caiJiaGe;//菜品价格
     private String caiLeixing; //菜品类型

     */
    public class InitilizeInfo {
         static Map<Integer,CaiPin> caiPinMap=new HashMap<>();
        static {
            if (caiPinMap.isEmpty()){
                CaiPin c1 = new CaiPin(1, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c2 = new CaiPin(2, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c3 = new CaiPin(3, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c4 = new CaiPin(4, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c5 = new CaiPin(5, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c6 = new CaiPin(6, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c7 = new CaiPin(7, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c8 = new CaiPin(8, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c9 = new CaiPin(9, "川菜", "毛血旺", 100.00, "荤菜");
                CaiPin c10 = new CaiPin(10, "川菜", "毛血旺", 100.00, "荤菜");
                caiPinMap.put(c1.getCaiBianHao(), c1);
                caiPinMap.put(c2.getCaiBianHao(), c2);
                caiPinMap.put(c3.getCaiBianHao(), c3);
                caiPinMap.put(c4.getCaiBianHao(), c4);
                caiPinMap.put(c5.getCaiBianHao(), c5);
                caiPinMap.put(c6.getCaiBianHao(), c6);
                caiPinMap.put(c7.getCaiBianHao(), c7);
                caiPinMap.put(c8.getCaiBianHao(), c8);
                caiPinMap.put(c9.getCaiBianHao(), c9);
                caiPinMap.put(c10.getCaiBianHao(), c10);
                ObjectOutputStream oos= null;
                try {
                    oos= new ObjectOutputStream(new FileOutputStream("菜品.txt"));
                    oos.writeObject(caiPinMap);
                    oos.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }finally {
                    try {
                        oos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
            }

            }
        }

    }


