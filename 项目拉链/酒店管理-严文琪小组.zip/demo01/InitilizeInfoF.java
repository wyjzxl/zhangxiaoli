package demo01;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2018/8/23.
 */
public class InitilizeInfoF {
        public static Map<Integer,FangJian> fangjianMap=new HashMap<>();
        static {
            if (fangjianMap.isEmpty()){
                FangJian f1=new FangJian(111,"大陆","天上人间",10000,"总统");
                FangJian f2=new FangJian(222,"香港","天上人间",10000,"双人");
                FangJian f3=new FangJian(333,"台湾","天上人间",10000,"单人");
                FangJian f4=new FangJian(444,"日韩","天上人间",10000,"情趣");
                FangJian f5=new FangJian(555,"欧美","天上人间",10000,"大床");
                fangjianMap.put(f1.getFangBianHao(),f1);
                fangjianMap.put(f2.getFangBianHao(),f2);
                fangjianMap.put(f3.getFangBianHao(),f3);
                fangjianMap.put(f4.getFangBianHao(),f4);
                fangjianMap.put(f5.getFangBianHao(),f5);
                ObjectOutputStream oos=null;
                try {
                    oos= new ObjectOutputStream(new FileOutputStream("房间.txt"));
                    oos.writeObject(fangjianMap);
                    oos.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }finally {
                    try {
                        oos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }


