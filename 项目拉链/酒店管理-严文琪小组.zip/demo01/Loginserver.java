package demo01;

import java.io.*;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 * Created by Administrator on 2018/8/15.
 * 服务端
 */
public class Loginserver {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        //1、快递点
        try {
            while (true) {

                ServerSocket serverSocket = new ServerSocket(8888);
                //2、监听
                Socket socket = serverSocket.accept();
                //3、打开输入流
                InputStream is = socket.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                String info = null;
                while ((info = br.readLine()) != null) {
                    System.out.println("对方输入内容：" + info);
                }
                //给客户端回应
                OutputStream os = socket.getOutputStream();

                System.out.print("我方输入内容：");
                String reply = input.next();
                os.write(reply.getBytes());

                br.close();
                is.close();
                socket.close();
                serverSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
