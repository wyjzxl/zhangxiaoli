package demo01;


import java.io.Serializable;

/**
     * Created by 杨帆 on 2018/8/23.
     * 菜品类
     */
    public class CaiPin implements Serializable{
        private int caiBianHao;//菜品编号
        private String caiXiLie; //菜系
        private String caiName;//菜品名称
        private double caiJiaGe;//菜品价格
        private String caiLeixing; //菜品类型

        public CaiPin() {
        }

        public CaiPin(int caiBianHao, String caiXiLie, String caiName, double caiJiaGe, String caiLeixing) {
            this.caiBianHao = caiBianHao;
            this.caiXiLie = caiXiLie;
            this.caiName = caiName;
            this.caiJiaGe = caiJiaGe;
            this.caiLeixing = caiLeixing;
        }

        public int getCaiBianHao() {
            return caiBianHao;
        }

        public void setCaiBianHao(int caiBianHao) {
            this.caiBianHao = caiBianHao;
        }

        public String getCaiXiLie() {
            return caiXiLie;
        }

        public void setCaiXiLie(String caiXiLie) {
            this.caiXiLie = caiXiLie;
        }

        public String getCaiName() {
            return caiName;
        }

        public void setCaiName(String caiName) {
            this.caiName = caiName;
        }

        public double getCaiJiaGe() {
            return caiJiaGe;
        }

        public void setCaiJiaGe(double caiJiaGe) {
            this.caiJiaGe = caiJiaGe;
        }

        public String getCaiLeixing() {
            return caiLeixing;
        }

        public void setCaiLeixing(String caiLeixing) {
            this.caiLeixing = caiLeixing;
        }


    }


