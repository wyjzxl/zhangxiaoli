package demo01;

/**
 * Created by Administrator on 2018/8/22.
 */
public class Test {
    public static void main(String[] args) {
        Opera opera=new Opera();
        opera.firstMenu();
    }
}
