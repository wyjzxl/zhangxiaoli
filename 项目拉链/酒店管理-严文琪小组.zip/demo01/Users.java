package demo01;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/8/22.
 */
public class Users implements Serializable{
    private String name;//姓名
    private String nameID;//身份证号
    private String phoneNo;//手机号
    private String accountNo;//账号
    private String pwd;//密码
    private double money;//账户余额

    public Users(String name, String nameID, String phoneNo, String accountNo, String pwd, double money) {
        this.name = name;
        this.nameID = nameID;
        this.phoneNo = phoneNo;
        this.accountNo = accountNo;
        this.pwd = pwd;
        this.money = money;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameID() {
        return nameID;
    }

    public void setNameID(String nameID) {
        this.nameID = nameID;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
}

