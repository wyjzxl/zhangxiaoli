package demo01;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/8/23.
 */
    public class FangJian implements Serializable {
        private int fangBianHao;//房间编号
        private String fangFengG; //房间风格
        private String fangName;//房间名称
        private double fangJiaGe;//房间价格
        private String fangLeixing; //房间类型

        public FangJian() {
        }

        public FangJian(int fangBianHao, String fangFengG, String fangName, double fangJiaGe, String fangLeixing) {
            this.fangBianHao = fangBianHao;
            this.fangFengG = fangFengG;
            this.fangName = fangName;
            this.fangJiaGe = fangJiaGe;
            this.fangLeixing = fangLeixing;
        }

        public int getFangBianHao() {
            return fangBianHao;
        }

        public void setFangBianHao(int fangBianHao) {
            this.fangBianHao = fangBianHao;
        }

        public String getFangFengG() {
            return fangFengG;
        }

        public void setFangFengG(String fangFengG) {
            this.fangFengG = fangFengG;
        }

        public String getFangName() {
            return fangName;
        }

        public void setFangName(String fangName) {
            this.fangName = fangName;
        }

        public double getFangJiaGe() {
            return fangJiaGe;
        }

        public void setFangJiaGe(double fangJiaGe) {
            this.fangJiaGe = fangJiaGe;
        }

        public String getFangLeixing() {
            return fangLeixing;
        }

        public void setFangLeixing(String fangLeixing) {
            this.fangLeixing = fangLeixing;
        }
    }


