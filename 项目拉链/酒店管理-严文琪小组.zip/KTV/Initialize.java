package KTV;



import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2018/8/23 0023.
 * 初始化歌词信息
 */
public class Initialize {
    static Map<String,Song> map=new HashMap<>();
    static {
       String fj =gc.fj;
       String zmdqd= gc.zmdqd;
       String qmzm=gc.qmzm;
        Song g=new Song("最美的期待",zmdqd);
        map.put(g.getName(),g);
        Song g1=new Song("房间",fj);
        map.put(g1.getName(),g1);
        Song g2=new Song("青梅竹马",qmzm);
        map.put(g2.getName(),g2);
    }
}
