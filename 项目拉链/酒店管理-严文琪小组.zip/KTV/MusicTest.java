package KTV;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;
/**
 * Created by Administrator on 2018/8/23 0023.
 * 放歌工具类
 */
    public  class MusicTest {
        public String path;// 音乐路径
        public boolean loop;// 是否循环
        public AdvancedPlayer ap;
        public InputStream is;// 文件流
        public MusicTest(String path, boolean loop) {           //构造方法，传歌曲地址
            this.path = path;
            this.loop = loop;
            try {
                is = new FileInputStream(path);//创建文件流，读取音乐
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                ap = new AdvancedPlayer(is);//将这个文件流放在播放器里
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }
        public MusicTest play() {
            do {
                try {
                    ap.play();//播放
                } catch (JavaLayerException e) {
                    e.printStackTrace();
                }
            } while (loop);
            return null;
        }
    }
