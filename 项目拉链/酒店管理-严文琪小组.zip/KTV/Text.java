package KTV;



/**
 * Created by Administrator on 2018/8/23 0023.
 * 测试类
 */
public class Text {
    public void music() {
        Toop t= new Toop();
        Thread thread = new Thread(t,"歌曲");
        thread.start();
        while (true){
            Thread.yield();
                if (Toop.j==1){
                    new MusicTest("D:/IDE项目new/src/KTV/zmdqd.mp3", false).play();
                    break;
                }if (Toop.j==2){
                    new MusicTest("D:/IDE项目new/src/KTV/fangjian.mp3", false).play();
                    break;
                }
        }
        }
    }

