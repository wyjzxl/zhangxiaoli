package KTV;

import java.util.Map;

import java.util.Scanner;

/**
 * Created by yaolei on 2018/8/23 0023.
 * 工具类
 */
public class Toop implements Runnable{
   static public int j;
    Scanner input =new Scanner(System.in);
    Map<String,Song> map=Initialize.map;
    @Override
    public void run() {
        cg();
    }
    //点歌
    public synchronized void cg(){
        String []st;
        System.out.println("1.最美的期待  2.房间  3.青梅竹马");
        System.out.print("请选择：");
        j =input.nextInt();

        switch (j){
            case 1:
                System.out.println(Thread.currentThread().getName()+"：  "+"最美的期待");
                String li = map.get("最美的期待").getGc();
                st=li.split("\n");
//                try {
//                    Thread.sleep(1000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
                bl(st);
                break;
            case 2:
                System.out.println(Thread.currentThread().getName()+"：  "+"房间");
                map.get("房间");
                String li2 = map.get("房间").getGc();
                st=li2.split("\n");
                bl(st);
                break;
            case 3:
                System.out.println(Thread.currentThread().getName()+"：  "+"青梅竹马");
                map.get("青梅竹马");
                String li3 = map.get("青梅竹马").getGc();
                st=li3.split("\n");
                bl(st);
                break;
                default:
        }
    }
    //遍历数组
    public synchronized void bl(String[] sts){
        for (int i = 0; i <sts.length ; i++) {
            if (sts[i]!=null){
                try {
                    Thread.sleep(2500);
                    System.out.println(sts[i]);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
