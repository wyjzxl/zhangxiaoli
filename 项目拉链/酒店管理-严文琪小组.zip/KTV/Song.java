package KTV;

/**
 * Created by yl on 2018/8/23 0023.
 */
public class Song {
    private String name;
    private String gc;

    public Song() {
    }

    public Song(String name, String gc) {
        this.name = name;
        this.gc = gc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGc() {
        return gc;
    }

    public void setGc(String gc) {
        this.gc = gc;
    }
}
